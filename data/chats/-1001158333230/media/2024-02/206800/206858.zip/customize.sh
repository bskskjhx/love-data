#!/system/bin/sh

if [ $KSU ];then
    ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
    if ! [ "$KSU_KERNEL_VER_CODE" ] || [ "$KSU_KERNEL_VER_CODE" -lt 11563 ]; then
        ui_print "*********************************************************"
        ui_print "! KernelSU 版本太旧!"
        ui_print "! 请将 KernelSU 更新到最新版本"
        abort "*********************************************************"
    fi
else
    abort "不是KernelSU来凑什么热闹?"
fi

