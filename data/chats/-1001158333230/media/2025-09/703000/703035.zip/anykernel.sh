properties() { '
kernel.string=CmdLine Patch Tool
do.devicecheck=1
do.modules=0
do.cleanup=1
do.cleanuponabort=0
device.name1=xuanyuan
device.name2=dijun
device.name3=aurora
device.name4=munch
device.name5=haotian
supported.versions=
'; }
block=/dev/block/by-name/vendor_boot;
is_slot_device=1;
ramdisk_compression=none;
. tools/ak3-core.sh;
split_boot;

# begin ramdisk changes
patch_cmdline zram.num_devices zram.num_devices=0
flash_boot;
## end install