if [ -e /my_product/vendor/etc/multimedia_display_feature_config.xml ]; then
    origin=/my_product/vendor/etc/multimedia_display_feature_config.xml
else
    abort "File not found!"
fi

if [[ $origin == *my_product* ]]; then
    target=$MODPATH/multimedia_display_feature_config.xml
    echo -e '#!/system/bin/sh\nmount -o ro,bind ${0%/*}/multimedia_display_feature_config.xml /my_product/vendor/etc/multimedia_display_feature_config.xml' > $MODPATH/post-fs-data.sh
    # echo 'sleep 60; umount /my_bigball/etc/permissions/oplus_google_cn_gms_features.xml' > $MODPATH/service.sh
elif [[ $KSU ]]; then
    target=$MODPATH$origin    
else
    target=$MODPATH/system$origin
fi

mkdir -p $(dirname $target)
cp -f $origin $MODPATH/multimedia_display_feature_config.xml.bak
cp -f $MODPATH/multimedia_display_feature_config.xml $target

ui_print "modify $origin"
