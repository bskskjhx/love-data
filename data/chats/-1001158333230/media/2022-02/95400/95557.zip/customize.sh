SKIPMOUNT=true
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 ****************************

[[更新日志]]
全面更新
增加app控制器
增强优化
 "

mkdir -p /sdcard/Android/HoucTouch
cat $MODPATH/配置.conf > /sdcard/Android/HoucTouch/配置.conf
echo "不可删除" > /sdcard/Android/HoucTouch/请勿删除该目录任何文件
set_perm_recursive $MODPATH 0 0 0755 0777
su -c $MODPATH/touch.sh >/dev/null 2>&1

if [ -d "/data/adb/modules/HCChukonG" ];then
	echo "检测到Hc旧版模块冲突，重启后默认移除旧模块"
touch /data/adb/modules/HCChukonG/remove
fi
if [ -d "/data/adb/modules/HCextra" ];then
	echo "检测到Hc旧版模块冲突，重启后默认移除旧模块"
touch /data/adb/modules/HCextra/remove
fi

echo "已为您更新到最新版本"
sleep 1
echo "初始化"