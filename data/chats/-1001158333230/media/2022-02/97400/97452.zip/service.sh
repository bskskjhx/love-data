while [[ "$(cat /sys/fs/f2fs/*/cp_interval)" != "200" ]]; do
  echo 200 > /sys/fs/f2fs/*/cp_interval
  sleep 1
done

while [[ "$(cat /sys/fs/f2fs/*/gc_urgent_sleep_time)" != "50" ]]; do
  echo 50 > /sys/fs/f2fs/*/gc_urgent_sleep_time
  sleep 1
done

while [[ "$(cat /sys/fs/f2fs/*/iostat_enable)" != "1" ]]; do
  echo 1 > /sys/fs/f2fs/*/iostat_enable
  sleep 1
done

while [[ "$(cat /sys/block/sda/queue/discard_max_bytes)" != "134217728" ]]; do
  echo 134217728 > /sys/block/sda/queue/discard_max_bytes
  sleep 1
done

if [[ "$(cat /sys/fs/f2fs/*/gc_urgent_sleep_time)" = "50" ]]; then
  chmod 0444 /sys/fs/f2fs/*/gc_urgent_sleep_time
fi
