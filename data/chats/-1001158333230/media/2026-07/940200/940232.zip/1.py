#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging

HOST = "127.0.0.1"
PORT = 18080
ALLOW_PATH = "/api/sig/by-card/v1"
AUDIT_LOG = "final_mock_audit.log"

logging.basicConfig(filename=AUDIT_LOG, level=logging.INFO, encoding="utf-8")

SUCCESS_RESPONSE = {
    "success": True,
    "sig": "AQIDBAUG",
    "message": "fixture ok",
    "credits_cost": 0,
    "credits_left": 999
}

class MockSigHandler(BaseHTTPRequestHandler):
    def _send_json(self, status_code, body):
        data = json.dumps(body, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/health":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok\n")
        else:
            self._send_json(404, {"error": "Not Found"})

    def do_POST(self):
        path = self.path.split("?")[0]
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else b""

        if path != ALLOW_PATH:
            self._send_json(404, {"error": "Not Found", "path": path})
            return

        logging.info("REQUEST %s", body.decode("utf-8", errors="replace"))
        self._send_json(200, SUCCESS_RESPONSE)

    def log_message(self, fmt, *args):
        pass

def main():
    server = ThreadingHTTPServer((HOST, PORT), MockSigHandler)
    print(f"[*] Listening on http://{HOST}:{PORT}")
    print(f"[*] Path: {ALLOW_PATH}")
    print(f"[*] Response: {SUCCESS_RESPONSE}")
    server.serve_forever()

if __name__ == "__main__":
    main()