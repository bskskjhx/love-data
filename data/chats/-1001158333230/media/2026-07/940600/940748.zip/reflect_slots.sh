cd /dev/block/by-name

for p in \
  apusys audio_dsp boot ccu connsys_gnss dpm dtbo gpueb gz init_boot ise \
  logo lk mcf_ota mcupm modem mvpu_algo pi_img preloader_raw pvmfw rotfw scp \
  spmfw sspm storage tee vbmeta vbmeta_system vbmeta_vendor vcp vendor_boot
do
  [ -e "${p}_a" ] && [ -e "${p}_b" ] || continue
  echo "== $p =="
  dd if="${p}_a" of="${p}_b" bs=4M conv=fsync
done

sync