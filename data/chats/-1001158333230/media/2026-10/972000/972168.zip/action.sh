#!/system/bin/sh

MODID="zygisk_fake_signature"
WEBUIX_PACKAGE="com.dergoogler.mmrl.wx"
WEBUIX_ACTIVITY="$WEBUIX_PACKAGE/.ui.activity.webui.WebUIActivity"
WEBUIX_API="https://api.github.com/repos/MMRLApp/WebUI-X-Portable/releases/latest"
WEBUIX_RELEASES="https://github.com/MMRLApp/WebUI-X-Portable/releases/latest"
APK_PATH="/data/local/tmp/webuix.apk"
API_PATH="/data/local/tmp/webuix.json"

download() {
    if command -v curl >/dev/null 2>&1; then
        curl --connect-timeout 15 --fail --location --silent --show-error "$1"
    elif [ -x /data/adb/magisk/busybox ]; then
        /data/adb/magisk/busybox wget -T 20 --no-check-certificate -qO- "$1"
    else
        busybox wget -T 20 --no-check-certificate -qO- "$1"
    fi
}

open_download_page() {
    echo "! Could not install WebUI X automatically."
    echo "- Opening the official WebUI X releases page."
    am start -a android.intent.action.VIEW -d "$WEBUIX_RELEASES"
    exit 1
}

launch_webuix() {
    echo "- Opening WebUI in WebUI X..."
    if am start -n "$WEBUIX_ACTIVITY" -e MOD_ID "$MODID"; then
        echo "- WebUI launched."
        exit 0
    fi
    echo "! Could not open WebUI X."
    exit 1
}

if pm path "$WEBUIX_PACKAGE" >/dev/null 2>&1; then
    launch_webuix
fi

if pm path io.github.a13e300.ksuwebui >/dev/null 2>&1; then
    echo "- Opening WebUI in KsuWebUIStandalone..."
    if am start -n "io.github.a13e300.ksuwebui/.WebUIActivity" -e id "$MODID"; then
        echo "- WebUI launched."
        exit 0
    fi
    echo "! Could not open KsuWebUIStandalone."
    exit 1
fi

echo "- WebUI X is not installed; downloading the latest official release..."
if ! download "$WEBUIX_API" > "$API_PATH"; then
    rm -f "$API_PATH"
    open_download_page
fi

APK_URL=$(grep -o '"browser_download_url":[[:space:]]*"[^"]*\.apk"' "$API_PATH" \
    | head -n 1 | cut -d '"' -f 4)
rm -f "$API_PATH"
case "$APK_URL" in
    https://github.com/MMRLApp/WebUI-X-Portable/releases/download/*/*.apk)
        ;;
    *)
        open_download_page
        ;;
esac

echo "- Downloading WebUI X APK..."
if ! download "$APK_URL" > "$APK_PATH" || [ ! -s "$APK_PATH" ]; then
    rm -f "$APK_PATH"
    open_download_page
fi

echo "- Installing WebUI X..."
if ! pm install -r "$APK_PATH"; then
    rm -f "$APK_PATH"
    open_download_page
fi
rm -f "$APK_PATH"

if ! pm path "$WEBUIX_PACKAGE" >/dev/null 2>&1; then
    echo "! WebUI X installation did not register package $WEBUIX_PACKAGE."
    exit 1
fi

launch_webuix
