window.FakeSignatureI18n = {
  en: {
    title: "Signature spoofing access",
    language: "Language",
    intro: "Only apps that declare FAKE_PACKAGE_SIGNATURE are listed. Choose which of them may read a configured fake signature.",
    search: "Search package names",
    refresh: "Refresh",
    save: "Save access",
    loading: "Loading installed apps and access settings…",
    loaded: "Loaded {count} apps declaring the permission; {authorized} authorized.",
    saving: "Saving access settings…",
    saved: "Access settings saved for {count} apps.",
    noApps: "No installed apps declaring the permission were found.",
    noMatches: "No matching apps.",
    authorize: "Allow {name} to read a spoofed signature",
    unsupportedManager: "This manager does not provide the WebUI command API.",
    commandFailed: "Command failed: {message}"
  },
  zh: {
    title: "签名伪装授权",
    language: "语言",
    intro: "这里只列出声明了 FAKE_PACKAGE_SIGNATURE 的应用。选择允许读取已配置伪造签名的应用。",
    search: "搜索应用包名",
    refresh: "刷新",
    save: "保存授权",
    loading: "正在读取已安装应用和授权设置…",
    loaded: "已加载 {count} 个声明该权限的应用；已授权 {authorized} 个。",
    saving: "正在保存授权设置…",
    saved: "已保存 {count} 个应用的授权。",
    noApps: "没有找到声明该权限的已安装应用。",
    noMatches: "没有匹配的应用。",
    authorize: "允许 {name} 读取伪造签名",
    unsupportedManager: "当前管理器未提供 WebUI 命令接口。",
    commandFailed: "命令执行失败：{message}"
  }
};
