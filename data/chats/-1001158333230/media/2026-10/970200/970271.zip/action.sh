#!/system/bin/sh
MODDIR=${0%/*}

# 检查 service.sh 是否存在并调用其 now 分支
if [ -f "$MODDIR/service.sh" ]; then
    sh "$MODDIR/service.sh" now
else
    echo "======================================="
    echo "错误: 未能在模块目录找到 service.sh"
    echo "======================================="
fi