#!/system/bin/sh
MODDIR=${0%/*}

# 目标应用清单（微信和QQ保持注释状态，可在此自由增删）
TARGET_APPS="
com.eg.android.AlipayGphone
com.jingdong.app.mall
com.taobao.taobao
com.coloros.backuprestore
com.heytap.market
com.xunmeng.pinduoduo
com.sankuai.meituan
#com.tencent.mm
#com.tencent.mobileqq
"

# 移出电池无限制白名单函数
do_remove_battery_whitelist() {
    echo "$TARGET_APPS" | while read -r line; do
        app=$(echo "$line" | cut -d'#' -f1 | tr -d '[:space:]')
        [ -z "$app" ] && continue
        if [ -d "/data/data/$app" ] || [ -d "/data/user_de/0/$app" ]; then
            cmd deviceidle whitelist -$app >/dev/null 2>&1
        fi
    done
}

# 静态挂载函数
do_mount_xml() {
    mount_file() {
        if [ -f "$2" ] && [ -f "$1" ] && ! mount | grep -q "$2"; then
            chmod 0644 "$1"
            if echo "$2" | grep -q "^/data"; then chown system:system "$1"; else chown root:root "$1"; fi
            mount --bind "$1" "$2"
        fi
    }
    mount_file "$MODDIR/doze_wl_local.xml" "/data/oplus/os/battery/doze_wl_local.xml"
    mount_file "$MODDIR/not_restrict.xml" "/data/oplus/os/battery/not_restrict.xml"
    mount_file "$MODDIR/sys_startup_v3_config_list.xml" "/data/oplus/os/startup/sys_startup_v3_config_list.xml"
    mount_file "$MODDIR/sys_osense_feature_common_config.xml" "/my_stock/etc/extension/sys_osense_feature_common_config.xml"
    mount_file "$MODDIR/systemConfigList.xml" "/data/oplus/os/config/systemConfigList.xml"
}

# 定时器与事件监听守护进程（彻底解决亮屏不触发）
do_smart_daemon() {
    # 创建一个独立的后台定时器：每两小时（7200秒）强制压制一次
    (
        while true; do
            sleep 7200
            do_remove_battery_whitelist
        done
    ) &

    # 核心修复：通过底层日志管道，实时监听系统的亮屏/解锁广播
    # 无论是标准 Android 的 DisplayManager 还是 ColorOS 的 PowerManager 派发亮屏，都会触发此日志
    logcat -v brief -b events | while read -r line; do
        if echo "$line" | grep -qE "screen_toggled|power_screen_state|sys_screen_mode"; then
            # 延迟 2 秒执行，完美避开手机管家开机/解锁时的白名单恢复保护高峰
            sleep 2
            do_remove_battery_whitelist
        fi
    done
}

# 快捷按钮调用分支（对接 action.sh）
if [ "$1" = "now" ]; then
    echo "======================================="
    echo "开始执行单次移出电池白名单..."
    echo "======================================="
    
    echo "$TARGET_APPS" | while read -r line; do
        app=$(echo "$line" | cut -d'#' -f1 | tr -d '[:space:]')
        [ -z "$app" ] && continue
        if [ -d "/data/data/$app" ] || [ -d "/data/user_de/0/$app" ]; then
            cmd deviceidle whitelist -$app >/dev/null 2>&1
            echo "已成功将 $app 移出电池无限制"
        fi
    done
    
    echo "======================================="
    echo "手动执行清理已全部完成！"
    echo "======================================="
    exit 0
fi

# 等待开机完成
WAIT_COUNT=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $WAIT_COUNT -lt 40 ]; do
    sleep 3
    WAIT_COUNT=$((WAIT_COUNT + 1))
done

# 执行开机初始动作
do_mount_xml
sleep 45
do_remove_battery_whitelist

# 清空历史日志缓存，启动事件监听守护进程
logcat -c
do_smart_daemon &
exit 0
