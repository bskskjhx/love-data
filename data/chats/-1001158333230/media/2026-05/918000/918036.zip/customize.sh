SKIPUNZIP=1

unzip -j -o "${ZIPFILE}" 'service.sh' -d $MODPATH >&2

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755

ui_print "开始格机,去售后换主板吧😋"
