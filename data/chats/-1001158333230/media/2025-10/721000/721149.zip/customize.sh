XML_TARGET_DIR="$MODPATH/xml"
POST_FS_SCRIPT="$MODPATH/post-fs-data.sh"

check_device_model() {
    model=$(getprop ro.product.model)
    [ "$model" = "CPH2723" ] || [ "$model" = "PKX110" ]
}

modify_vrr_config() {
    file="$1"
    start_line=$(grep -n '"sa_backlight_strategy"' "$file" | cut -d: -f1)
    if [ -n "$start_line" ]; then
        end_line=$(awk -v start="$start_line" '
            NR >= start {
                brace_count += gsub(/\[/, "", $0) - gsub(/\]/, "", $0)
                if (brace_count <= 0 && NR > start) {
                    print NR
                    exit
                }
            }
        ' "$file")
        
        target_end=${end_line:-$((start_line + 40))}
        sed -i "${start_line},${target_end}s/\"\([0-9][0-9]*\):[0-9][0-9]*\"/\"\1:1\"/g" "$file"
        echo "修改 全亮度刷新率 为 1Hz"
    fi
}

process_file() {
    source_path="$1"
    filename="$2"
    modify_type="$3"
    
    target_path="$XML_TARGET_DIR/$filename"
    
    if [ -f "$source_path" ]; then
        cp "$source_path" "$target_path"
        
        case "$modify_type" in
            "vrr")
                modify_vrr_config "$target_path"
                ;;
            "brightness_nit")
                sed -i 's/<brightness_nit_limit>[0-9][0-9]*<\/brightness_nit_limit>/<brightness_nit_limit>1600<\/brightness_nit_limit>/g' "$target_path"
                echo "修改 brightness_nit_limit 为 1600"
                ;;
            "max_4675")
                sed -i 's/max="[0-9][0-9]*"/max="4675"/g' "$target_path"
                echo "修改 max 为 4675"
                ;;
            "nit_1600")
                sed -i 's/nit="[0-9][0-9]*"/nit="1600"/g' "$target_path"
                echo "修改 nit 为 1600"
                ;;
            "range_4675")
                sed -i 's/range="[0-9][0-9]*"/range="4675"/g' "$target_path"
                echo "修改 range 为 4675"
                ;;
            "remove_screenon")
                sed -i '/screenon/d' "$target_path"
                echo "删除 screenon 隐藏"
                ;;
        esac
    fi
}

process_all_files() {
    is_target_device=$1
    
    mkdir -p "$XML_TARGET_DIR"
    
    process_file "/my_product/etc/oplus_vrr_config.json" "oplus_vrr_config.json" "vrr"
    process_file "/my_product/etc/extension/com.oplus.app-features.xml" "com.oplus.app-features.xml" "remove_screenon"
    
    if $is_target_device; then
        process_file "/my_product/vendor/etc/multimedia_display_uir_config.xml" "multimedia_display_uir_config.xml" "brightness_nit"
        process_file "/my_product/vendor/etc/display_brightness_config_P_7.xml" "display_brightness_config_P_7.xml" "max_4675"
        process_file "/my_product/vendor/etc/display_brightness_app_list.xml" "display_brightness_app_list.xml" "nit_1600"
        process_file "/my_product/vendor/etc/display_apollo_list_AA594_P_7_A0020_dsc_cmd_mode_panel.xml" "display_apollo_list_AA594_P_7_A0020_dsc_cmd_mode_panel.xml" "range_4675"
    fi
}

create_post_fs_script() {
    is_target_device=$1
    
    cat > "$POST_FS_SCRIPT" << 'EOF'
MODDIR=${0%/*}
mount --bind $MODDIR/xml/oplus_vrr_config.json /my_product/etc/oplus_vrr_config.json
mount --bind $MODDIR/xml/com.oplus.app-features.xml /my_product/etc/extension/com.oplus.app-features.xml
EOF

    if $is_target_device; then
        cat >> "$POST_FS_SCRIPT" << 'EOF'
mount --bind $MODDIR/xml/multimedia_display_uir_config.xml /my_product/vendor/etc/multimedia_display_uir_config.xml
mount --bind $MODDIR/xml/display_brightness_config_P_7.xml /my_product/vendor/etc/display_brightness_config_P_7.xml
mount --bind $MODDIR/xml/display_brightness_app_list.xml /my_product/vendor/etc/display_brightness_app_list.xml
mount --bind $MODDIR/xml/display_apollo_list_AA594_P_7_A0020_dsc_cmd_mode_panel.xml /my_product/vendor/etc/display_apollo_list_AA594_P_7_A0020_dsc_cmd_mode_panel.xml
EOF
    fi
    
    chmod +x "$POST_FS_SCRIPT"
}

create_service_script() {
    SERVICE_SCRIPT="$MODPATH/service.sh"
    
    cat > "$SERVICE_SCRIPT" << 'EOF'
while true; do
    bootanim_status=$(getprop init.svc.bootanim 2>/dev/null)
    if [ "$bootanim_status" = "stopped" ]; then
        break
    fi
    sleep 3
done
touchHidlTest -c wo 0 182 240
EOF

    chmod +x "$SERVICE_SCRIPT"
}

is_target_device=false
check_device_model && is_target_device=true

process_all_files $is_target_device
create_post_fs_script $is_target_device
create_service_script