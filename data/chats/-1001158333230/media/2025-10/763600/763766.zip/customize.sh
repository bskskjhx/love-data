XML_TARGET_DIR="$MODPATH/xml"
POST_FS_SCRIPT="$MODPATH/post-fs-data.sh"

check_device_model() {
    model=$(getprop ro.product.model)
    [ "$model" = "CPH2723" ] || [ "$model" = "PKX110" ]
}

get_android_version() {
    version=$(getprop ro.build.version.release)
    echo "$version"
}

modify_vrr_config() {
    file="$1"
    start_line=$(grep -n '"sa_backlight_strategy"' "$file" | cut -d: -f1)
    if [ -n "$start_line" ]; then
        end_line=$(awk -v start="$start_line" '
            NR >= start {
                brace_count += gsub(/\[/, "", $0) - gsub(/\]/, "", $0)
                if (brace_count <= 0 && NR > start) {
                    print NR
                    exit
                }
            }
        ' "$file")

        target_end=${end_line:-$((start_line + 40))}
        sed -i "${start_line},${target_end}s/\"\([0-9][0-9]*\):[0-9][0-9]*\"/\"\1:1\"/g" "$file"
        echo "All Brightness 1Hz Patch Done"
    fi
}

modify_aod_features() {
    file="$1"
    sed -i 's/name="oplus\.aod\.wakebyclick\.support".*args="boolean:[^"]*"/name="oplus.aod.wakebyclick.support" args="boolean:true"/g' "$file"
    sed -i 's/name="com\.oplus\.systemui\.panoramic_aod\.enable".*args="boolean:[^"]*"/name="com.oplus.systemui.panoramic_aod.enable" args="boolean:true"/g' "$file"
    sed -i 's/name="oplus\.software\.disable_aod_all_day_mode".*args="boolean:[^"]*"/name="oplus.software.disable_aod_all_day_mode" args="boolean:false"/g' "$file"
    sed -i 's/name="com\.oplus\.systemui\.panoramic_aod_all_day_default_open\.enable".*args="boolean:[^"]*"/name="com.oplus.systemui.panoramic_aod_all_day_default_open.enable" args="boolean:true"/g' "$file"
    sed -i 's/name="com\.oplus\.systemui\.panoramic_aod_all_day\.enable".*args="boolean:[^"]*"/name="com.oplus.systemui.panoramic_aod_all_day.enable" args="boolean:true"/g' "$file"
    sed -i 's/name="oplus_keyguard_panoramic_aod_all_day_support".*args="boolean:[^"]*"/name="oplus_keyguard_panoramic_aod_all_day_support" args="boolean:true"/g' "$file"
    if ! grep -q 'name="oplus\.aod\.wakebyclick\.support"' "$file"; then
        sed -i "/<\/extend_features>/i\\	<app_feature name=\"oplus.aod.wakebyclick.support\" args=\"boolean:true\"\/>" "$file"
    fi
    if ! grep -q 'name="com\.oplus\.systemui\.panoramic_aod\.enable"' "$file"; then
        sed -i "/<\/extend_features>/i\\	<app_feature name=\"com.oplus.systemui.panoramic_aod.enable\" args=\"boolean:true\"\/>" "$file"
    fi
    if ! grep -q 'name="oplus\.software\.disable_aod_all_day_mode"' "$file"; then
        sed -i "/<\/extend_features>/i\\	<app_feature name=\"oplus.software.disable_aod_all_day_mode\" args=\"boolean:false\"\/>" "$file"
    fi
    if ! grep -q 'name="com\.oplus\.systemui\.panoramic_aod_all_day_default_open\.enable"' "$file"; then
        sed -i "/<\/extend_features>/i\\	<app_feature name=\"com.oplus.systemui.panoramic_aod_all_day_default_open.enable\" args=\"boolean:true\"\/>" "$file"
    fi
    if ! grep -q 'name="com\.oplus\.systemui\.panoramic_aod_all_day\.enable"' "$file"; then
        sed -i "/<\/extend_features>/i\\	<app_feature name=\"com.oplus.systemui.panoramic_aod_all_day.enable\" args=\"boolean:true\"\/>" "$file"
    fi
    if ! grep -q 'name="oplus_keyguard_panoramic_aod_all_day_support"' "$file"; then
        sed -i "/<\/extend_features>/i\\	<app_feature name=\"oplus_keyguard_panoramic_aod_all_day_support\" args=\"boolean:true\"\/>" "$file"
    fi
}

process_file() {
    source_path="$1"
    filename="$2"
    modify_type="$3"

    target_path="$XML_TARGET_DIR/$filename"

    if [ -f "$source_path" ]; then
        cp "$source_path" "$target_path"

        case "$modify_type" in
            "vrr")
                modify_vrr_config "$target_path"
                ;;
            "app_features")
                android_version=$(getprop ro.build.version.release)
                if [ "$android_version" = "15" ]; then
                    sed -i '/screenon/d' "$target_path"
                    echo "Fullsceen AOD Patch Skipped"
                    echo "Battery Screen-on Patch Done"
                else
                    modify_aod_features "$target_path"
                    echo "Fullsceen AOD Patch Done"
                    echo "Battery Screen-on Patch Skipped"
                fi
                ;;
            "brightness_nit")
                sed -i 's/<brightness_nit_limit>[0-9][0-9]*<\/brightness_nit_limit>/<brightness_nit_limit>1600<\/brightness_nit_limit>/g' "$target_path"
                echo "Patch brightness_nit_limit Done"
                ;;
            "max_4675")
                sed -i 's/max="[0-9][0-9]*"/max="4675"/g' "$target_path"
                echo "Patch Max 4675 Done"
                ;;
            "nit_1600")
                sed -i 's/nit="[0-9][0-9]*"/nit="1600"/g' "$target_path"
                echo "Patch Nit 1600 Done"
                ;;
            "range_4675")
                sed -i 's/range="[0-9][0-9]*"/range="4675"/g' "$target_path"
                echo "Patch Range 4675 Done"
                ;;
        esac
    fi
}

process_all_files() {
    mkdir -p "$XML_TARGET_DIR"

    process_file "/my_product/etc/oplus_vrr_config.json" "oplus_vrr_config.json" "vrr"
    process_file "/my_product/etc/extension/com.oplus.app-features.xml" "com.oplus.app-features.xml" "app_features"
    process_file "/my_product/vendor/etc/multimedia_display_uir_config.xml" "multimedia_display_uir_config.xml" "brightness_nit"
    process_file "/my_product/vendor/etc/display_brightness_config_P_7.xml" "display_brightness_config_P_7.xml" "max_4675"
    process_file "/my_product/vendor/etc/display_brightness_app_list.xml" "display_brightness_app_list.xml" "nit_1600"
    process_file "/my_product/vendor/etc/display_apollo_list_AA594_P_7_A0020_dsc_cmd_mode_panel.xml" "display_apollo_list_AA594_P_7_A0020_dsc_cmd_mode_panel.xml" "range_4675"
}

create_post_fs_script() {
    cat > "$POST_FS_SCRIPT" << 'EOF'
MODDIR=${0%/*}
mount --bind $MODDIR/xml/oplus_vrr_config.json /my_product/etc/oplus_vrr_config.json
mount --bind $MODDIR/xml/com.oplus.app-features.xml /my_product/etc/extension/com.oplus.app-features.xml
mount --bind $MODDIR/xml/multimedia_display_uir_config.xml /my_product/vendor/etc/multimedia_display_uir_config.xml
mount --bind $MODDIR/xml/display_brightness_config_P_7.xml /my_product/vendor/etc/display_brightness_config_P_7.xml
mount --bind $MODDIR/xml/display_brightness_app_list.xml /my_product/vendor/etc/display_brightness_app_list.xml
mount --bind $MODDIR/xml/display_apollo_list_AA594_P_7_A0020_dsc_cmd_mode_panel.xml /my_product/vendor/etc/display_apollo_list_AA594_P_7_A0020_dsc_cmd_mode_panel.xml
EOF

    chmod +x "$POST_FS_SCRIPT"
}

create_service_script() {
    SERVICE_SCRIPT="$MODPATH/service.sh"
    
    cat > "$SERVICE_SCRIPT" << 'EOF'
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 3
done
touchHidlTest -c wo 0 182 240
EOF

    chmod +x "$SERVICE_SCRIPT"
    echo "Force Polling Rate 240Hz Done"
}

if ! check_device_model; then
    ui_print "Not OnePlus 13t/s"
    ui_print "Current: $(getprop ro.product.model)"
    abort
fi

ui_print "Current: $(getprop ro.product.model)"
ui_print "Android Version: $(get_android_version)"

process_all_files
create_post_fs_script
create_service_script