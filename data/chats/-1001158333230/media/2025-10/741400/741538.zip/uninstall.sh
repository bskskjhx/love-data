#!/system/bin/sh

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

su -c pm enable com.google.android.gms/.update.SystemUpdateActivity
su -c pm enable com.google.android.gms/.update.SystemUpdateService
su -c pm enable com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver
su -c pm enable com.google.android.gms/.update.SystemUpdateService\$Receiver
su -c pm enable com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver
su -c pm enable com.google.android.gsf/.update.SystemUpdateActivity
su -c pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity
su -c pm enable com.google.android.gsf/.update.SystemUpdateService
su -c pm enable com.google.android.gsf/.update.SystemUpdateService\$Receiver
su -c pm enable com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver