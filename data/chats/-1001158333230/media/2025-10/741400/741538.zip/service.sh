#!/system/bin/sh

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

su -c pm disable com.google.android.gms/.update.SystemUpdateActivity
su -c pm disable com.google.android.gms/.update.SystemUpdateService
su -c pm disable com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver
su -c pm disable com.google.android.gms/.update.SystemUpdateService\$Receiver
su -c pm disable com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver
su -c pm disable com.google.android.gsf/.update.SystemUpdateActivity
su -c pm disable com.google.android.gsf/.update.SystemUpdatePanoActivity
su -c pm disable com.google.android.gsf/.update.SystemUpdateService
su -c pm disable com.google.android.gsf/.update.SystemUpdateService\$Receiver
su -c pm disable com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver