#Module description
Camera stack by eszdman