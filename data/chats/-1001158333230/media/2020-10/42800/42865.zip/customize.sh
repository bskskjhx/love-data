#!/system/bin/sh

  ui_print "*******************************"
  ui_print "    Es Camera Improvements!     "
  ui_print "*******************************"


DEVICE=`getprop ro.product.device`



ui_print "bruh "
 ui_print "Installing Es Camera Improvments for "$DEVICE" ..."

