# Magisk Font Google [<a href="https://twitter.com/topjohnwu/status/1229896206584664065">DISCONTINUED</a>]

## Testing devices

- Google Nexus 4 Android Lollipop/Oreo
- Google Nexus 6 Android Marshmallow
- OnePlus 5 Android Nougat/Oreo/Pie/Ten

## Known bug

- Lockscreen colon may not show in some rom

## Contact

- <a href="https://github.com/Magisk-Modules-Repo/Magisk_Font_Google/issues">Commit an Issue</a>
- <a href="https://t.me/pirasalbe">Telegram</a>

## Donate

<a href="https://paypal.me/pirasalbe">Paypal</a>

## Changelog

#### 2.3

- Update magisk module template
- Update font files

#### 2.2

- Update magisk module template

#### 2.1R

- Font more regular
- Fix config

#### 2.1C

- Font more condensed
- Fix config

#### 2.0R

- Font more regular
- Updated magisk module template 1500

#### 2.0C

- Font more condensed
- Updated magisk module template 1500

#### 1.1

- Updated fonts

##### Previous versions

Test versions

## Thanks

- <a href="https://github.com/topjohnwu">topjohnwu</a>
- <a href="https://github.com/HUMORCE">HUMORCE</a> <a href="https://github.com/Magisk-Modules-Repo/Systemlessly-Font-with-Tsukushimarugo-A-CJK-Sleek">(his font)</a>
- <a href="https://forum.xda-developers.com/android/themes/fonts-flashable-zips-t3219827">gianton and dude6595</a>
- <a href="https://github.com/sergiocastell">linuxct</a> <a href="https://github.com/sergiocastell/AndroidO-NotoColorEmojiReplacer">(his module)</a>
- <a href="https://t.me/Catellone">@Catellone</a> for fixing lockscreen colon bug
- <a href="https://github.com/Magisk-Modules-Repo/Pix3lify/">Pix3lify</a>
- **All of them that helped with tests and issues**
