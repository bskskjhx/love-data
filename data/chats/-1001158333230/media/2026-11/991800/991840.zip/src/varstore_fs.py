#!/usr/bin/env python3
"""Unpack / pack Qualcomm DataStore+vAR2 uefivarstore images.

Layout (all derived from the PTBL, nothing copied verbatim except field values):

  0x0        PTBL: u32 sig, u32 ver, u32 total_sectors, u32 nparts,
                    nparts * {u32 id, u16 start_sector, u16 num_sectors, u8 acl[8]}
  per partition, 2 banks (bank b at start + b*(num_sectors//2) sectors):
    table_off  = start + b*(num_sectors//2) + 1   (sectors, 4 KiB)
    DStr header @ table_off - 1 sector
    VAR2 table  @ table_off
    DStr footer @ table_off + (num_sectors//2 - 2) sectors
  table:  VarStorageTableHdr { "VAR2", ver, cur, max, attrs }
          GuidRecord { size, EFI_GUID, VariableRecord[] }
          VariableRecord { recsize, props, resv, datalen, namelen,
                           name UTF-16LE, pad, data, slack }

`pad` (between name and data) and `slack` (to recsize) are don't-care bytes;
the packer always writes zeros there.  All CRC32 fields are recomputed.

Commands:
  unpack <img> <dir>     manifest.json + vars/<p>_b<bank>/<guid>/<name>.bin
  pack   <dir> <img>     rebuild image from manifest + payloads
  selftest <img>         unpack -> pack -> byte compare
  set <dir> --guid G --name N --value-file F [--table-attrs 0x7]
                         insert/replace a variable in every matching bank
  
  Copyright © 2002-2026 NekoYuzu (MlgmXyysd) All Rights Reserved.
"""
import argparse, hashlib, json, os, struct, sys, tempfile, uuid, zlib

SECTOR = 0x1000
VAR2_SIG = b'VAR2'
DSTR_SIG = b'DStr'
DS_FIELDS = ('version', 'age', 'write', 'cfg', 'maxps', 'actps', 'sync',
             'res0', 'pad1', 'res1')


def err(msg):
    raise SystemExit('error: ' + msg)


def guid_str(b):
    return str(uuid.UUID(bytes_le=bytes(b)))


def guid_bytes(s):
    return uuid.UUID(s).bytes_le


def safe_component(name):
    out = []
    for ch in name:
        if (ch.isalnum() and ord(ch) < 128) or ch in '._-':
            out.append(ch)
        else:
            out.append(''.join('%%%02X' % x for x in ch.encode('utf-8')))
    return ''.join(out) or '_'


# --------------------------------------------------------------------------- #
# DataStoreInfo
# --------------------------------------------------------------------------- #
def ds_parse(d, off):
    if d[off:off + 4] != DSTR_SIG:
        err('no DStr at %#x' % off)
    ver, age, wm, cfg, maxps, actps, sync, tcrc, res0, pad1 = \
        struct.unpack_from('<6H4I', d, off + 4)
    res1, = struct.unpack_from('<Q', d, off + 0x20)
    return dict(version=ver, age=age, write=wm, cfg=cfg, maxps=maxps,
                actps=actps, sync=sync, res0=res0, pad1=pad1, res1=res1,
                tablecrc=tcrc, crc=struct.unpack_from('<I', d, off + 0x28)[0])


def ds_build(fields, tablecrc):
    hdr = DSTR_SIG + struct.pack('<6H4I', fields['version'], fields['age'],
                                 fields['write'], fields['cfg'], fields['maxps'],
                                 fields['actps'], fields['sync'], tablecrc,
                                 fields['res0'], fields['pad1'])
    hdr += struct.pack('<Q', fields['res1'])
    assert len(hdr) == 0x28
    return hdr + struct.pack('<I', zlib.crc32(hdr))


# --------------------------------------------------------------------------- #
# VAR2 table
# --------------------------------------------------------------------------- #
def table_parse(d, t):
    sig, ver, cur, maxsz, attrs = struct.unpack_from('<5I', d, t)
    if sig != 0x32524156:
        err('no VAR2 at %#x' % t)
    pos, end = t + 0x14, t + cur
    groups = []
    while pos < end:
        gsz, = struct.unpack_from('<I', d, pos)
        if gsz < 20 or pos + gsz > end:
            err('bad GuidRecord size %#x at %#x' % (gsz, pos))
        g = d[pos + 4:pos + 20]
        p, rem = pos + 20, gsz - 20
        recs = []
        while rem > 0:
            rsz, props, resv, dsz, nsz = struct.unpack_from('<IIIIH', d, p)
            if rsz < 18 or rsz > rem:
                err('bad VariableRecord size %#x at %#x' % (rsz, p))
            raw_name = d[p + 18:p + 18 + nsz].decode('utf-16-le', 'replace')
            if not raw_name.endswith('\x00'):
                err('name not NUL terminated at %#x' % p)
            pad = (18 + nsz) % 4
            doff = p + 18 + nsz + pad
            data = d[doff:doff + dsz]
            recs.append(dict(name=raw_name[:-1], props=props, resv=resv,
                             recsize=rsz, datalen=dsz, data=data))
            p += rsz
            rem -= rsz
        groups.append(dict(guid=guid_str(g), records=recs))
        pos += gsz
    if pos != end:
        err('table at %#x does not end at CurrTableSize' % t)
    return dict(version=ver, curr_size=cur, max_size=maxsz, attrs=attrs,
                groups=groups)


def record_build(r, data):
    name = r['name'].encode('utf-16-le') + b'\x00\x00'
    nsz = len(name)
    pad_len = (18 + nsz) % 4
    hdr = struct.pack('<IIIIH', r['recsize'], r['props'], r['resv'],
                      len(data), nsz)
    body = hdr + name + b'\x00' * pad_len + data
    need = r['recsize'] - len(body)
    if need < 0:
        err('record %r: data too large for recsize 0x%x' % (r['name'], r['recsize']))
    return body + b'\x00' * need


def table_build(groups, version, max_size, attrs):
    buf = bytearray(VAR2_SIG + struct.pack('<4I', version, 0, max_size, attrs))
    for g in groups:
        gstart = len(buf)
        buf += b'\x00' * 4 + guid_bytes(g['guid'])
        for r in g['records']:
            payload = open(r['data'], 'rb').read() if isinstance(r['data'], str) else r['data']
            buf += record_build(r, payload)
        struct.pack_into('<I', buf, gstart, len(buf) - gstart)
    struct.pack_into('<I', buf, 8, len(buf))
    return bytes(buf)


# --------------------------------------------------------------------------- #
# image layout
# --------------------------------------------------------------------------- #
def ptbl_parse(d):
    if d[:4] != b'PTBL':
        err('no PTBL header')
    ver, total, npart = struct.unpack_from('<III', d, 4)
    parts = []
    for i in range(npart):
        pid, start, num = struct.unpack_from('<IHH', d, 0x10 + i * 16)
        parts.append(dict(id=pid, start_sector=start, num_sectors=num,
                          acl=d[0x18 + i * 16:0x20 + i * 16].hex()))
    return dict(version=ver, total_sectors=total, partitions=parts)


def bank_offsets(ptbl, pidx, bank):
    p = ptbl['partitions'][pidx]
    half = p['num_sectors'] // 2
    table = p['start_sector'] * SECTOR + bank * half * SECTOR + SECTOR
    footer = table + (p['num_sectors'] // 2 - 2) * SECTOR
    return table, table - SECTOR, footer


def unpack(img, outdir):
    d = open(img, 'rb').read()
    ptbl = ptbl_parse(d)
    os.makedirs(outdir, exist_ok=True)
    banks = []
    for pidx, p in enumerate(ptbl['partitions']):
        for bank in (0, 1):
            table_off, hdr_off, foot_off = bank_offsets(ptbl, pidx, bank)
            ent = dict(partition=pidx, bank=bank, present=False)
            if d[table_off:table_off + 4] == VAR2_SIG:
                tab = table_parse(d, table_off)
                hdr = ds_parse(d, hdr_off)
                foot = ds_parse(d, foot_off)
                for k in DS_FIELDS + ('tablecrc',):
                    if hdr[k] != foot[k]:
                        err('header/footer %s differ for bank %d/%d' % (k, pidx, bank))
                groups = []
                for g in tab['groups']:
                    recs = []
                    for r in g['records']:
                        rel = os.path.join('vars', 'p%d_b%d' % (pidx, bank),
                                           g['guid'], safe_component(r['name']))
                        base, n = rel, 1
                        while os.path.exists(os.path.join(outdir, rel)):
                            n += 1
                            rel = '%s__%d' % (base, n)
                        os.makedirs(os.path.dirname(os.path.join(outdir, rel)),
                                    exist_ok=True)
                        open(os.path.join(outdir, rel), 'wb').write(r['data'])
                        recs.append(dict(name=r['name'], props=r['props'],
                                         resv=r['resv'], recsize=r['recsize'],
                                         datalen=len(r['data']), data=rel))
                    groups.append(dict(guid=g['guid'], records=recs))
                ent.update(present=True,
                           table=dict(version=tab['version'],
                                      max_size=tab['max_size'],
                                      attrs=tab['attrs'],
                                      curr_size=tab['curr_size']),
                           datastore={k: hdr[k] for k in DS_FIELDS},
                           groups=groups)
            banks.append(ent)
    manifest = dict(image_size=len(d), ptbl=ptbl, banks=banks)
    with open(os.path.join(outdir, 'manifest.json'), 'w') as f:
        json.dump(manifest, f, indent=1)
    return manifest


def pack(indir, outimg):
    manifest = json.load(open(os.path.join(indir, 'manifest.json')))
    ptbl = manifest['ptbl']
    d = bytearray(manifest['image_size'])
    d[0:4] = b'PTBL'
    struct.pack_into('<III', d, 4, ptbl['version'], ptbl['total_sectors'],
                     len(ptbl['partitions']))
    for i, p in enumerate(ptbl['partitions']):
        off = 0x10 + i * 16
        struct.pack_into('<IHH', d, off, p['id'], p['start_sector'],
                         p['num_sectors'])
        d[off + 8:off + 16] = bytes.fromhex(p['acl'])
    for b in manifest['banks']:
        if not b['present']:
            continue
        table_off, hdr_off, foot_off = bank_offsets(ptbl, b['partition'], b['bank'])
        # resolve payloads relative to indir
        groups = []
        for g in b['groups']:
            recs = []
            for r in g['records']:
                r = dict(r)
                r['data'] = os.path.join(indir, r['data'])
                recs.append(r)
            groups.append(dict(guid=g['guid'], records=recs))
        table = table_build(groups, b['table']['version'], b['table']['max_size'],
                            b['table']['attrs'])
        if len(table) > foot_off - table_off:
            err('table at %#x grows past footer' % table_off)
        d[table_off:table_off + len(table)] = table
        ds = ds_build(b['datastore'], zlib.crc32(table))
        d[hdr_off:hdr_off + len(ds)] = ds
        d[foot_off:foot_off + len(ds)] = ds
    open(outimg, 'wb').write(d)


def dont_care_intervals(manifest):
    """Ranges that may legitimately differ after a repack: record pad/slack
    (normalized to 0) and the derived DataStoreInfo CRC fields."""
    ivs = []
    ptbl = manifest['ptbl']
    for b in manifest['banks']:
        if not b['present']:
            continue
        t, _, _ = bank_offsets(ptbl, b['partition'], b['bank'])
        pos = t + 0x14
        for g in b['groups']:
            pos += 0x14
            for r in g['records']:
                nsz = 2 * len(r['name']) + 2
                pad_off = pos + 18 + nsz
                pad_len = (18 + nsz) % 4
                slack_off = pad_off + pad_len + r['datalen']
                slack_end = pos + r['recsize']
                if pad_len:
                    ivs.append((pad_off, pad_off + pad_len, 'padslack'))
                if slack_off < slack_end:
                    ivs.append((slack_off, slack_end, 'padslack'))
                pos += r['recsize']
    for b in manifest['banks']:
        if not b['present']:
            continue
        _, hdr_off, foot_off = bank_offsets(ptbl, b['partition'], b['bank'])
        for o in (hdr_off, foot_off):
            ivs.append((o + 0x14, o + 0x18, 'crc'))   # TableCrc32
            ivs.append((o + 0x28, o + 0x2c, 'crc'))   # DataStoreInfo.Crc32
    return ivs


def selftest(img):
    tmp = tempfile.mkdtemp(prefix='varstore_selftest_')
    try:
        manifest = unpack(img, tmp)
        out = os.path.join(tmp, 'repacked.img')
        pack(tmp, out)
        a = open(img, 'rb').read()
        b = open(out, 'rb').read()
        sha = hashlib.sha256(a).hexdigest()
        if a == b:
            print('IDENTICAL  %d bytes  sha256=%s' % (len(a), sha))
            return 0
        diff = [i for i in range(min(len(a), len(b))) if a[i] != b[i]]
        ivs = dont_care_intervals(manifest)
        bad, cnt = [], {'padslack': 0, 'crc': 0}
        for i in diff:
            for lo, hi, kind in ivs:
                if lo <= i < hi:
                    cnt[kind] += 1
                    break
            else:
                bad.append(i)
        if bad or len(a) != len(b):
            print('DIFFERS  %d bytes outside pad/slack/CRC (first: %s)' %
                  (len(bad) + abs(len(a) - len(b)),
                   ', '.join('%#x' % i for i in bad[:16])))
            return 1
        print('EQUIVALENT  %d bytes differ: %d pad/slack (normalized to 0) + '
              '%d derived CRC fields; sha256(src)=%s' %
              (len(diff), cnt['padslack'], cnt['crc'], sha))
        return 0
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def cmd_set(indir, guid, name, value_file, table_attrs):
    manifest = json.load(open(os.path.join(indir, 'manifest.json')))
    value = open(value_file, 'rb').read()
    nb = name.encode('utf-16-le') + b'\x00\x00'
    pad_len = (18 + len(nb)) % 4
    content = 18 + len(nb) + pad_len + len(value)
    recsize = (content + 3) & ~3
    changed = 0
    for b in manifest['banks']:
        if not b['present'] or (table_attrs is not None and
                                b['table']['attrs'] != table_attrs):
            continue
        group = next((g for g in b['groups'] if g['guid'].lower() == guid.lower()), None)
        if group is None:
            print('bank p%d_b%d: GUID %s not present, creating group' %
                  (b['partition'], b['bank'], guid))
            group = dict(guid=guid, records=[])
            b['groups'].append(group)
        rel = os.path.join('vars', 'p%d_b%d' % (b['partition'], b['bank']),
                           guid, safe_component(name))
        base, n = rel, 1
        while os.path.exists(os.path.join(indir, rel)):
            n += 1
            rel = '%s__%d' % (base, n)
        os.makedirs(os.path.dirname(os.path.join(indir, rel)), exist_ok=True)
        open(os.path.join(indir, rel), 'wb').write(value)
        rec = dict(name=name, props=0, resv=0, recsize=recsize,
                   datalen=len(value), data=rel)
        old = next((r for r in group['records'] if r['name'] == name), None)
        if old is None:
            group['records'].append(rec)
            print('bank p%d_b%d: appended %r (%d bytes, recsize 0x%x)' %
                  (b['partition'], b['bank'], name, len(value), recsize))
        else:
            group['records'][group['records'].index(old)] = rec
            print('bank p%d_b%d: replaced %r (%d bytes, recsize 0x%x)' %
                  (b['partition'], b['bank'], name, len(value), recsize))
        changed += 1
    if not changed:
        err('no matching bank (attrs=%s)' % table_attrs)
    with open(os.path.join(indir, 'manifest.json'), 'w') as f:
        json.dump(manifest, f, indent=1)


def cmd_del(indir, guid, name, table_attrs):
    manifest = json.load(open(os.path.join(indir, 'manifest.json')))
    changed = 0
    for b in manifest['banks']:
        if not b['present']:
            continue
        if table_attrs is not None and b['table']['attrs'] != table_attrs:
            continue
        group = next((g for g in b['groups'] if g['guid'].lower() == guid.lower()), None)
        if group is None:
            continue
        before = len(group['records'])
        group['records'] = [r for r in group['records'] if r['name'] != name]
        if len(group['records']) == before:
            continue
        if not group['records']:
            b['groups'].remove(group)
        changed += 1
        print('bank p%d_b%d: removed %r' % (b['partition'], b['bank'], name))
    if not changed:
        err('record %r not found' % name)
    with open(os.path.join(indir, 'manifest.json'), 'w') as f:
        json.dump(manifest, f, indent=1)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('unpack'); p.add_argument('img'); p.add_argument('dir')
    p = sub.add_parser('pack'); p.add_argument('dir'); p.add_argument('img')
    p = sub.add_parser('selftest'); p.add_argument('img')
    p = sub.add_parser('set')
    p.add_argument('dir')
    p.add_argument('--guid', required=True)
    p.add_argument('--name', required=True)
    p.add_argument('--value-file', required=True)
    p.add_argument('--table-attrs', type=lambda x: int(x, 0), default=None)
    p = sub.add_parser('del')
    p.add_argument('dir')
    p.add_argument('--guid', required=True)
    p.add_argument('--name', required=True)
    p.add_argument('--table-attrs', type=lambda x: int(x, 0), default=None)
    a = ap.parse_args()
    if a.cmd == 'unpack':
        unpack(a.img, a.dir)
        print('unpacked %s -> %s' % (a.img, a.dir))
    elif a.cmd == 'pack':
        pack(a.dir, a.img)
        print('packed %s -> %s' % (a.dir, a.img))
    elif a.cmd == 'selftest':
        sys.exit(selftest(a.img))
    elif a.cmd == 'set':
        cmd_set(a.dir, a.guid, a.name, a.value_file, a.table_attrs)
    elif a.cmd == 'del':
        cmd_del(a.dir, a.guid, a.name, a.table_attrs)


if __name__ == '__main__':
    main()
