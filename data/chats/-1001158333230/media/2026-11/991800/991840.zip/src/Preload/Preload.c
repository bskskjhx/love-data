/** @file
  Preload: mount the "qmcs" partition, disable the PMIC PON watchdog,
  ensure a Boot#### option for itself exists and is in BootOrder, set
  BootNext to it, then start \efisp\BDS.efi.

  SPDX-License-Identifier: BSD-2-Clause-Patent
  
  Copyright © 2002-2026 NekoYuzu (MlgmXyysd) All Rights Reserved.
**/

#include <Uefi.h>

#include <Library/UefiLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/UefiBootManagerLib.h>
#include <Library/BaseLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/DevicePathLib.h>
#include <Library/BlkIoHandleLib.h>
#include <Library/MountFatLib.h>

#include <Protocol/LoadedImage.h>
#include <Protocol/DevicePath.h>
#include <IndustryStandard/PeImage.h>
#include <Guid/GlobalVariable.h>

#define PRELOAD_BDS_PATH  L"\\efisp\\BDS.efi"

/* Private PMIC PwrOn protocol extension (vendor PmicDxe). */
extern EFI_GUID  gQcomPmicPwrOnProtocolGuid;

typedef struct {
  UINT64  Revision;
  UINT64  Functions[18];
} QCOM_PMIC_PWRON_RAW;

typedef EFI_STATUS (EFIAPI *PMIC_WDOG_ENABLE)(UINT32 PmicIndex, UINT8 Enable);
typedef EFI_STATUS (EFIAPI *PMIC_WDOG_STATUS)(UINT32 PmicIndex, UINT8 *Status);

#define PON_FUNC_ENABLE  15   /* +0x80 */
#define PON_FUNC_PET     16   /* +0x88 */
#define PON_FUNC_STATUS  17   /* +0x90 */

STATIC
BOOLEAN
IsExecutableAddress (
  IN EFI_PHYSICAL_ADDRESS  ImageBase,
  IN EFI_PHYSICAL_ADDRESS  Address
  )
{
  EFI_IMAGE_DOS_HEADER      *Dos;
  EFI_IMAGE_NT_HEADERS64    *Nt;
  EFI_IMAGE_SECTION_HEADER  *Section;
  UINTN                     Index;
  UINT64                    Start;
  UINT64                    Size;

  if ((Address & 0x3) != 0) {
    return FALSE;
  }

  Dos = (EFI_IMAGE_DOS_HEADER *)(UINTN)ImageBase;
  if (Dos->e_magic != EFI_IMAGE_DOS_SIGNATURE) {
    return FALSE;
  }

  Nt = (EFI_IMAGE_NT_HEADERS64 *)((UINT8 *)Dos + Dos->e_lfanew);
  if (Nt->Signature != EFI_IMAGE_NT_SIGNATURE) {
    return FALSE;
  }

  Section = (EFI_IMAGE_SECTION_HEADER *)(
              (UINT8 *)&Nt->OptionalHeader + Nt->FileHeader.SizeOfOptionalHeader
              );
  for (Index = 0; Index < Nt->FileHeader.NumberOfSections; Index++) {
    if ((Section[Index].Characteristics & EFI_IMAGE_SCN_MEM_EXECUTE) == 0) {
      continue;
    }

    Start = ImageBase + Section[Index].VirtualAddress;
    Size  = Section[Index].Misc.VirtualSize;
    if (Size == 0) {
      Size = Section[Index].SizeOfRawData;
    }

    if ((Address >= Start) && (Address < Start + Size)) {
      return TRUE;
    }
  }

  return FALSE;
}

STATIC
EFI_STATUS
FindContainingImage (
  IN  EFI_PHYSICAL_ADDRESS  Address,
  OUT EFI_PHYSICAL_ADDRESS  *ImageBase
  )
{
  EFI_STATUS                 Status;
  EFI_HANDLE                *Handles;
  UINTN                      HandleCount;
  UINTN                      Index;
  EFI_LOADED_IMAGE_PROTOCOL *LoadedImage;

  Handles     = NULL;
  HandleCount = 0;
  Status = gBS->LocateHandleBuffer (
                  ByProtocol,
                  &gEfiLoadedImageProtocolGuid,
                  NULL,
                  &HandleCount,
                  &Handles
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  Status = EFI_NOT_FOUND;
  for (Index = 0; Index < HandleCount; Index++) {
    LoadedImage = NULL;
    if (EFI_ERROR (
          gBS->HandleProtocol (
                 Handles[Index],
                 &gEfiLoadedImageProtocolGuid,
                 (VOID **)&LoadedImage
                 )
          )
        || (LoadedImage == NULL))
    {
      continue;
    }

    if ((Address >= (EFI_PHYSICAL_ADDRESS)(UINTN)LoadedImage->ImageBase) &&
        (Address < (EFI_PHYSICAL_ADDRESS)(UINTN)LoadedImage->ImageBase + LoadedImage->ImageSize))
    {
      *ImageBase = (EFI_PHYSICAL_ADDRESS)(UINTN)LoadedImage->ImageBase;
      Status     = EFI_SUCCESS;
      break;
    }
  }

  gBS->FreePool (Handles);
  return Status;
}

STATIC
VOID
ShowWdogStatus (
  IN UINT64  StatusFnAddr
  )
{
  PMIC_WDOG_STATUS  StatusFn;
  EFI_STATUS        Status;
  UINT8             St;

  if (StatusFnAddr == 0) {
    return;
  }

  St       = 0;
  StatusFn = (PMIC_WDOG_STATUS)StatusFnAddr;
  Status   = StatusFn (0, &St);
  if (!EFI_ERROR (Status)) {
    Print (
      L"Preload: PmicWdog: status=0x%02x%s\n",
      (UINT32)St,
      ((St & 0x40) != 0) ? L" (HLOS disabled)" : L""
      );
  }
}

STATIC
EFI_STATUS
DisablePmicWdog (
  VOID
  )
{
  QCOM_PMIC_PWRON_RAW  *Proto;
  EFI_STATUS           Status;
  UINT64               Enable;
  UINT64               Pet;
  UINT64               StatusFn;
  EFI_PHYSICAL_ADDRESS ImageBase;

  Proto = NULL;
  Status = gBS->LocateProtocol (
                  &gQcomPmicPwrOnProtocolGuid,
                  NULL,
                  (VOID **)&Proto
                  );
  if (EFI_ERROR (Status) || (Proto == NULL)) {
    Print (L"Preload: PmicWdog: PON protocol not found: %r\n", Status);
    return Status;
  }

  Enable   = Proto->Functions[PON_FUNC_ENABLE];
  Pet      = Proto->Functions[PON_FUNC_PET];
  StatusFn = Proto->Functions[PON_FUNC_STATUS];

  if ((Enable == 0) || (Pet == 0) || (StatusFn == 0)) {
    Print (L"Preload: PmicWdog: private wdog entries absent\n");
    return EFI_UNSUPPORTED;
  }

  if (((Enable | Pet | StatusFn) & 0x3) != 0) {
    Print (L"Preload: PmicWdog: private wdog entries not aligned\n");
    return EFI_UNSUPPORTED;
  }

  Status = FindContainingImage (
             (EFI_PHYSICAL_ADDRESS)(UINTN)Proto,
             &ImageBase
             );
  if (EFI_ERROR (Status)) {
    Print (L"Preload: PmicWdog: PmicDxe image not found: %r\n", Status);
    return Status;
  }

  if (!IsExecutableAddress (ImageBase, Enable) ||
      !IsExecutableAddress (ImageBase, Pet) ||
      !IsExecutableAddress (ImageBase, StatusFn))
  {
    Print (L"Preload: PmicWdog: wdog entries not in PmicDxe code\n");
    return EFI_UNSUPPORTED;
  }

  Status = ((PMIC_WDOG_ENABLE)Enable)(0, 0);
  Print (L"Preload: PmicWdog: disable -> %r\n", Status);
  ShowWdogStatus (StatusFn);
  return Status;
}

/**
  Mount the qmcs partition with MountFatPartition and return its block I/O
  handle.
**/
STATIC
EFI_STATUS
MountQmcsVolume (
  OUT EFI_HANDLE  *QmcsHandle
  )
{
  EFI_STATUS           Status;
  HANDLE_INFO          HandleInfoList[2];
  PARTI_SELECT_FILTER  Filter;
  UINT32               MaxHandles;

  Status = MountFatPartition (L"qmcs");
  if (EFI_ERROR (Status) && (Status != EFI_ALREADY_STARTED)) {
    return Status;
  }

  Filter.RootDeviceType = NULL;
  Filter.PartitionType  = NULL;
  Filter.PartitionLabel = L"qmcs";
  Filter.VolumeName     = NULL;

  MaxHandles = sizeof (HandleInfoList) / sizeof (HandleInfoList[0]);
  Status = GetBlkIOHandles (
             BLK_IO_SEL_MATCH_PARTITION_LABEL |
             BLK_IO_SEL_STRING_CASE_INSENSITIVE |
             BLK_IO_SEL_PARTITIONED_GPT |
             BLK_IO_SEL_MEDIA_TYPE_NON_REMOVABLE,
             &Filter,
             HandleInfoList,
             &MaxHandles
             );
  if (EFI_ERROR (Status) || (MaxHandles == 0)) {
    return EFI_NOT_FOUND;
  }

  *QmcsHandle = HandleInfoList[0].Handle;
  return EFI_SUCCESS;
}

/**
  Find a Boot#### whose FilePathList is this image's device path.  If none
  exists, create one with EfiBootManagerInitializeLoadOption and append it
  to BootOrder.
**/
STATIC
EFI_STATUS
FindOrCreateBootOption (
  IN  EFI_HANDLE  ImageHandle,
  OUT UINT16      *BootIndex
  )
{
  EFI_STATUS                    Status;
  EFI_LOADED_IMAGE_PROTOCOL     *LoadedImage;
  EFI_BOOT_MANAGER_LOAD_OPTION  *Options;
  EFI_BOOT_MANAGER_LOAD_OPTION  NewOption;
  UINTN                         OptionCount;
  UINTN                         Index;
  UINTN                         FilePathLen;

  LoadedImage = NULL;
  Status = gBS->HandleProtocol (
                  ImageHandle,
                  &gEfiLoadedImageProtocolGuid,
                  (VOID **)&LoadedImage
                  );
  if (EFI_ERROR (Status) || (LoadedImage == NULL) ||
      (LoadedImage->FilePath == NULL))
  {
    return EFI_NOT_FOUND;
  }

  FilePathLen = GetDevicePathSize (LoadedImage->FilePath);

  Options = EfiBootManagerGetLoadOptions (&OptionCount, LoadOptionTypeBoot);
  if (Options != NULL) {
    for (Index = 0; Index < OptionCount; Index++) {
      if ((Options[Index].FilePath != NULL) &&
          (GetDevicePathSize (Options[Index].FilePath) == FilePathLen) &&
          (CompareMem (Options[Index].FilePath, LoadedImage->FilePath, FilePathLen) == 0))
      {
        *BootIndex = (UINT16)Options[Index].OptionNumber;
        EfiBootManagerFreeLoadOptions (Options, OptionCount);
        return EFI_SUCCESS;
      }
    }

    EfiBootManagerFreeLoadOptions (Options, OptionCount);
  }

  Status = EfiBootManagerInitializeLoadOption (
             &NewOption,
             LoadOptionNumberUnassigned,
             LoadOptionTypeBoot,
             LOAD_OPTION_ACTIVE | LOAD_OPTION_CATEGORY_APP,
             L"Preload",
             LoadedImage->FilePath,
             NULL,
             0
             );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  Status = EfiBootManagerAddLoadOptionVariable (&NewOption, (UINTN)-1);
  if (!EFI_ERROR (Status)) {
    *BootIndex = (UINT16)NewOption.OptionNumber;
  }

  EfiBootManagerFreeLoadOption (&NewOption);
  return Status;
}

STATIC
EFI_STATUS
SetBootNext (
  IN UINT16  BootIndex
  )
{
  return gRT->SetVariable (
                L"BootNext",
                &gEfiGlobalVariableGuid,
                EFI_VARIABLE_NON_VOLATILE |
                EFI_VARIABLE_BOOTSERVICE_ACCESS |
                EFI_VARIABLE_RUNTIME_ACCESS,
                sizeof (BootIndex),
                &BootIndex
                );
}

STATIC
EFI_STATUS
LaunchBds (
  IN EFI_HANDLE  QmcsHandle,
  IN EFI_HANDLE  ImageHandle
  )
{
  EFI_STATUS                 Status;
  EFI_DEVICE_PATH_PROTOCOL  *BdsPath;
  EFI_HANDLE                 BdsHandle;
  UINTN                      ExitDataSize;
  CHAR16                     *ExitData;

  BdsHandle    = NULL;
  ExitData     = NULL;
  ExitDataSize = 0;

  BdsPath = FileDevicePath (QmcsHandle, PRELOAD_BDS_PATH);
  if (BdsPath == NULL) {
    return EFI_OUT_OF_RESOURCES;
  }

  Status = gBS->LoadImage (
                  FALSE,
                  ImageHandle,
                  BdsPath,
                  NULL,
                  0,
                  &BdsHandle
                  );
  FreePool (BdsPath);
  if (EFI_ERROR (Status)) {
    return Status;
  }

  Status = gBS->StartImage (BdsHandle, &ExitDataSize, &ExitData);
  gBS->UnloadImage (BdsHandle);
  if (ExitData != NULL) {
    FreePool (ExitData);
  }

  return Status;
}

EFI_STATUS
EFIAPI
UefiMain (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS  Status;
  EFI_HANDLE  QmcsHandle;
  UINT16      BootIndex;

  Status = DisablePmicWdog ();
  if (EFI_ERROR (Status)) {
    Print (L"Preload: PmicWdog disable skipped: %r\n", Status);
  }

  QmcsHandle = NULL;

  Status = MountQmcsVolume (&QmcsHandle);
  if (EFI_ERROR (Status)) {
    Print (L"Preload: qmcs partition not found: %r\n", Status);
    return Status;
  }

  Status = FindOrCreateBootOption (ImageHandle, &BootIndex);
  if (EFI_ERROR (Status)) {
    Print (L"Preload: boot option setup failed: %r\n", Status);
    return Status;
  }

  Status = SetBootNext (BootIndex);
  if (EFI_ERROR (Status)) {
    Print (L"Preload: BootNext failed: %r\n", Status);
    return Status;
  }

  Print (L"Preload: Boot%04x in BootOrder, BootNext set, starting BDS.efi\n", BootIndex);

  Status = LaunchBds (QmcsHandle, ImageHandle);
  if (EFI_ERROR (Status)) {
    Print (L"Preload: BDS.efi launch failed: %r\n", Status);
  }

  return Status;
}
