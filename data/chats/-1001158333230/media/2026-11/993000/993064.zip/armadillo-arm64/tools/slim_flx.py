#!/usr/bin/env python3
# Rebuild app.flx with smaller images and without the unused Armadillo.png.
import io, json, sys, zipfile
from PIL import Image

src, dst = sys.argv[1:3]
DROP = {'packages/armadillo/res/Armadillo.png'}


def jpeg(img, quality):
    out = io.BytesIO()
    img.convert('RGB').save(out, 'JPEG', quality=quality, optimize=True,
                            progressive=True)
    return out.getvalue()


def transform(name, data):
    if name == 'packages/armadillo/res/User.png':  # actually a 1365x1365 JPEG
        img = Image.open(io.BytesIO(data))
        return jpeg(img.resize((384, 384), Image.LANCZOS), 90)
    if name == 'packages/armadillo/res/Background.jpg':
        return jpeg(Image.open(io.BytesIO(data)), 90)  # same size, EXIF dropped
    if name == 'AssetManifest.json':
        manifest = json.loads(data)
        manifest.pop('res/Armadillo.png', None)
        return json.dumps(manifest, separators=(',', ':')).encode()
    return data


with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, 'w') as zout:
    for info in zin.infolist():
        if info.filename in DROP:
            continue
        data = transform(info.filename, zin.read(info.filename))
        zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
        zi.external_attr = info.external_attr
        zout.writestr(zi, data, compress_type=zipfile.ZIP_DEFLATED,
                      compresslevel=9)
        if len(data) != info.file_size:
            print('%-50s %8d -> %8d' % (info.filename, info.file_size, len(data)))
