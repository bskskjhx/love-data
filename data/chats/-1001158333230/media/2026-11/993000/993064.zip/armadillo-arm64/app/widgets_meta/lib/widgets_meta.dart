// Minimal stand-in for Fuchsia's widgets_meta annotations (metadata only).
class ExampleSize {
  final double width;
  final double height;
  const ExampleSize(this.width, this.height);
}

class ExampleValue {
  final dynamic value;
  const ExampleValue(this.value);
}
