#!/usr/bin/env python3
# Resolve Dart packages as pub would have on a given date (latest version published
# before the cutoff), download and extract the tarballs. Data only, nothing executed.
import json, sys, os, tarfile, io, urllib.request, re

CUTOFF = sys.argv[1]            # e.g. 2017-07-24
OUT = sys.argv[2]
roots = sys.argv[3:]
SKIP = {'flutter', 'flutter_test', 'sky_engine', 'test', 'quiver', 'barback', 'browser'}

def get(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers={'Accept': 'application/vnd.pub.v2+json'})) as r:
        return r.read()

def pick(name):
    info = json.loads(get('https://pub.dev/api/packages/' + name))
    vs = [v for v in info['versions'] if v.get('published', '9999') [:10] <= CUTOFF
          and '-' not in v['version']]
    return vs[-1]

seen, queue = {}, list(roots)
while queue:
    n = queue.pop()
    if n in seen or n in SKIP:
        continue
    v = pick(n)
    seen[n] = v['version']
    deps = (v['pubspec'].get('dependencies') or {})
    queue += [d for d, c in deps.items() if not (isinstance(c, dict) and ('sdk' in c or 'path' in c))]
    d = os.path.join(OUT, n)
    os.makedirs(d, exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(get(v['archive_url'])), mode='r:gz') as t:
        t.extractall(d, filter='data')
    print(n, v['version'], v['published'][:10])

with open(os.path.join(OUT, 'versions.json'), 'w') as f:
    json.dump(seen, f, indent=1, sort_keys=True)
