#!/usr/bin/env python3
# Minimal gclient replacement: shallow-fetch every dep in a DEPS file at its pinned rev.
import os, subprocess, sys, concurrent.futures as cf

root = sys.argv[1]          # dir that contains src/
deps_file = sys.argv[2]
prefix = sys.argv[3] if len(sys.argv) > 3 else ''

import ast

def load(path):
    # Safe parse: only literals, '+' concatenation and Var('x') lookups. Nothing is executed.
    tree = ast.parse(open(path).read(), path)
    scope = {}
    def ev(n):
        if isinstance(n, ast.Constant): return n.value
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Add): return ev(n.left) + ev(n.right)
        if isinstance(n, ast.Dict): return {ev(k): ev(v) for k, v in zip(n.keys, n.values)}
        if isinstance(n, ast.List): return [ev(e) for e in n.elts]
        if isinstance(n, ast.Call) and getattr(n.func, 'id', '') == 'Var':
            return scope['vars'][ev(n.args[0])]
        raise ValueError('unsupported node %s' % ast.dump(n)[:80])
    for st in tree.body:
        if isinstance(st, ast.Assign) and isinstance(st.targets[0], ast.Name):
            try: scope[st.targets[0].id] = ev(st.value)
            except ValueError: pass
    return scope

def fetch(dest, spec):
    url, _, rev = spec.partition('@')
    d = os.path.join(root, prefix, dest)
    if os.path.exists(os.path.join(d, '.git')) and subprocess.run(
            ['git', '-C', d, 'rev-parse', '-q', '--verify', 'HEAD'], capture_output=True).returncode == 0:
        return dest, 'skip'
    os.makedirs(d, exist_ok=True)
    run = lambda *a: subprocess.run(['git', '-C', d] + list(a), capture_output=True, text=True)
    run('init', '-q'); run('remote', 'add', 'origin', url)
    r = run('fetch', '-q', '--depth', '1', 'origin', rev or 'HEAD')
    if r.returncode:
        r = run('fetch', '-q', '--depth', '1', 'origin', 'refs/tags/' + rev)
    if r.returncode:
        return dest, 'FAIL ' + r.stderr.strip()[-200:]
    run('checkout', '-q', 'FETCH_HEAD')
    return dest, 'ok'

s = load(deps_file)
deps = dict(s.get('deps', {}))
for osname in ('android', 'unix'):
    deps.update(s.get('deps_os', {}).get(osname, {}))
deps = {k: v for k, v in deps.items() if v}
# parents first (src before src/x)
order = sorted(deps, key=lambda k: k.count('/'))
levels = {}
for k in order: levels.setdefault(k.count('/'), []).append(k)
for lvl in sorted(levels):
    with cf.ThreadPoolExecutor(8) as ex:
        for dest, st in ex.map(lambda k: fetch(k, deps[k]), levels[lvl]):
            print(st[:4], dest, st[4:] if st.startswith('FAIL') else '', flush=True)
