#!/usr/bin/env python3
# Rebuild the APK: new manifest, per-ABI engine (with the AOT snapshot linked in),
# old asset snapshots and signature removed. Alignment/signing is done afterwards.
#
# Usage: pack2.py src.apk dst.apk manifest.xml abi=engine.so... [asset:NAME=PATH...]
import sys, zipfile

src, dst, manifest = sys.argv[1:4]
abis, assets = {}, {}
for a in sys.argv[4:]:
    if a.startswith('asset:'):
        name, path = a[len('asset:'):].split('=', 1)
        assets['assets/' + name] = path
    else:
        abi, spec = a.split('=', 1)
        abis[abi] = spec
SNAPS = ['vm_snapshot_data', 'vm_snapshot_instr', 'isolate_snapshot_data', 'isolate_snapshot_instr']


def put(z, name, data, method=zipfile.ZIP_DEFLATED):
    zi = zipfile.ZipInfo(name, date_time=(1981, 1, 1, 0, 0, 0))
    zi.compress_type = method
    zi.external_attr = 0o644 << 16
    z.writestr(zi, data, compresslevel=9 if method == zipfile.ZIP_DEFLATED else None)


with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, 'w') as zout:
    put(zout, 'AndroidManifest.xml', open(manifest, 'rb').read())
    for info in zin.infolist():
        n = info.filename
        if (n == 'AndroidManifest.xml' or n.startswith('META-INF/') or n.startswith('lib/')
                or n in ['assets/' + s for s in SNAPS]):
            continue
        data = open(assets[n], 'rb').read() if n in assets else zin.read(n)
        method = zipfile.ZIP_STORED if n == 'resources.arsc' else info.compress_type
        put(zout, n, data, method)
    # The AOT snapshot is linked into libflutter.so; it is the only native library.
    for abi, so in abis.items():
        put(zout, 'lib/%s/libflutter.so' % abi, open(so, 'rb').read())
