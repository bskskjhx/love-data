#!/usr/bin/env python3
# Minimal Android binary XML (AXML) decoder/encoder. Pure parsing, no external tools.
import struct

RES_STRING_POOL, RES_XML, RES_XML_RESOURCE_MAP = 0x0001, 0x0003, 0x0180
START_NS, END_NS, START_EL, END_EL, CDATA = 0x0100, 0x0101, 0x0102, 0x0103, 0x0104
TYPE_STRING, TYPE_INT_DEC, TYPE_INT_HEX, TYPE_BOOL = 0x03, 0x10, 0x11, 0x12
NO = 0xFFFFFFFF


def _read_pool(b, off):
    _, hsz, size, count, scount, flags, sstart, _ = struct.unpack_from('<HHIIIIII', b, off)
    utf8 = flags & 0x100
    offs = struct.unpack_from('<%dI' % count, b, off + hsz)
    out = []
    for o in offs:
        p = off + sstart + o
        if utf8:
            n = b[p]; p += 2 if n & 0x80 else 1
            n = b[p]
            if n & 0x80: n = ((n & 0x7f) << 8) | b[p + 1]; p += 2
            else: p += 1
            out.append(b[p:p + n].decode('utf-8'))
        else:
            n = struct.unpack_from('<H', b, p)[0]; p += 2
            if n & 0x8000: n = ((n & 0x7fff) << 16) | struct.unpack_from('<H', b, p)[0]; p += 2
            out.append(b[p:p + 2 * n].decode('utf-16le'))
    return out, off + size


def decode(b):
    """Returns (events, resmap). Events reference strings by value, not index."""
    off = 8
    strings, off = _read_pool(b, off)
    S = lambda i: None if i == NO else strings[i]
    resmap = []
    events = []
    while off < len(b):
        t, hsz, size = struct.unpack_from('<HHI', b, off)
        if t == RES_XML_RESOURCE_MAP:
            resmap = list(struct.unpack_from('<%dI' % ((size - 8) // 4), b, off + 8))
        elif t in (START_NS, END_NS):
            line, _, pfx, uri = struct.unpack_from('<IIII', b, off + 8)
            events.append((t, line, S(pfx), S(uri)))
        elif t == START_EL:
            line, _, ns, name, _, _, cnt, _, _, _ = struct.unpack_from('<IIIIHHHHHH', b, off + 8)
            attrs = []
            for i in range(cnt):
                ans, aname, araw, _, _, dtype, data = struct.unpack_from('<IIIHBBI', b, off + 36 + 20 * i)
                rid = resmap[aname] if aname < len(resmap) else None
                attrs.append([S(ans), S(aname), rid, S(araw), dtype, data if dtype != TYPE_STRING else S(data)])
            events.append((t, line, S(ns), S(name), attrs))
        elif t == END_EL:
            line, _, ns, name = struct.unpack_from('<IIII', b, off + 8)
            events.append((t, line, S(ns), S(name)))
        off += size
    return events, resmap


def encode(events):
    # Attribute names with a resource id must come first in the pool, in resmap order.
    named = []
    for e in events:
        if e[0] == START_EL:
            for a in e[4]:
                if a[2] is not None and (a[1], a[2]) not in named:
                    named.append((a[1], a[2]))
    pool = [n for n, _ in named]
    def idx(s):
        if s is None: return NO
        if s not in pool: pool.append(s)
        return pool.index(s)
    body = b''
    for e in events:
        t = e[0]
        if t in (START_NS, END_NS):
            body += struct.pack('<HHIIIII', t, 16, 24, e[1], NO, idx(e[2]), idx(e[3]))
        elif t == START_EL:
            attrs = sorted(e[4], key=lambda a: (a[2] if a[2] is not None else 0xFFFFFFFF))
            ab = b''
            for ans, aname, rid, raw, dtype, data in attrs:
                ni = pool.index(aname) if rid is not None else idx(aname)
                d = idx(data) if dtype == TYPE_STRING else data
                ab += struct.pack('<IIIHBBI', idx(ans), ni, idx(raw), 8, 0, dtype, d & 0xFFFFFFFF)
            body += struct.pack('<HHIIIIIHHHHHH', t, 16, 36 + len(ab), e[1], NO, idx(e[2]), idx(e[3]),
                                20, 20, len(attrs), 0, 0, 0) + ab
        elif t == END_EL:
            body += struct.pack('<HHIIIII', t, 16, 24, e[1], NO, idx(e[2]), idx(e[3]))
    # UTF-16 string pool
    data, offs = b'', []
    for s in pool:
        offs.append(len(data))
        u = s.encode('utf-16le')
        data += struct.pack('<H', len(s)) + u + b'\0\0'
    while len(data) % 4: data += b'\0'
    hdr = 28
    sp = struct.pack('<HHIIIIII', RES_STRING_POOL, hdr, hdr + 4 * len(pool) + len(data), len(pool), 0, 0,
                     hdr + 4 * len(pool), 0) + struct.pack('<%dI' % len(pool), *offs) + data
    rm = struct.pack('<HHI', RES_XML_RESOURCE_MAP, 8, 8 + 4 * len(named)) + struct.pack('<%dI' % len(named), *[r for _, r in named])
    out = sp + rm + body
    return struct.pack('<HHI', RES_XML, 8, 8 + len(out)) + out


def dump(events):
    depth = 0
    for e in events:
        if e[0] == START_EL:
            print('  ' * depth + '<' + e[3])
            for a in e[4]:
                print('  ' * depth + '    %s=%r (type 0x%x, res 0x%s)' % (a[1], a[5], a[4], '%08x' % a[2] if a[2] else '-'))
            depth += 1
        elif e[0] == END_EL:
            depth -= 1


if __name__ == '__main__':
    import sys
    dump(decode(open(sys.argv[1], 'rb').read())[0])
