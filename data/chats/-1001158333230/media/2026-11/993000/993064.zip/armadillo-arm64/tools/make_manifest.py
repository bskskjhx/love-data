#!/usr/bin/env python3
# Derive the shipping AndroidManifest.xml from the original APK's binary manifest:
#   minSdk 16 -> 23 (packed relocations need API 23), targetSdk 21 -> 35,
#   MainActivity android:exported="true" (required for targetSdk >= 31),
#   <application android:allowNativeHeapPointerTagging="false"> (the 2017 engine
#   and Dart VM break with tagged heap pointers, enabled for targetSdk >= 30).
#
# Usage: make_manifest.py <original AndroidManifest.xml> <output.xml>
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import axml

ANDROID = 'http://schemas.android.com/apk/res/android'
ATTR_EXPORTED = 0x01010010
ATTR_ALLOW_NATIVE_HEAP_POINTER_TAGGING = 0x01010612

src, dst = sys.argv[1:3]
events, _ = axml.decode(open(src, 'rb').read())
for e in events:
    if e[0] != axml.START_EL:
        continue
    attrs = e[4]
    if e[3] == 'manifest':
        for a in attrs:
            if a[1] == 'platformBuildVersionCode': a[5] = 35
            if a[1] == 'platformBuildVersionName': a[5] = '15'
    elif e[3] == 'uses-sdk':
        for a in attrs:
            if a[1] == 'minSdkVersion': a[5] = 23
            if a[1] == 'targetSdkVersion': a[5] = 35
    elif e[3] == 'application':
        attrs.append([ANDROID, 'allowNativeHeapPointerTagging',
                      ATTR_ALLOW_NATIVE_HEAP_POINTER_TAGGING, None, axml.TYPE_BOOL, 0])
    elif e[3] == 'activity':
        attrs.append([ANDROID, 'exported', ATTR_EXPORTED, None, axml.TYPE_BOOL, 0xFFFFFFFF])
open(dst, 'wb').write(axml.encode(events))
