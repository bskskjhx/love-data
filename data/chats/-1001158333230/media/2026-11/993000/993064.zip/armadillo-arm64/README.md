# Armadillo（Fuchsia sysui，2017-07-26）arm64 重建版

把 2017 年 7 月 Fuchsia 团队发布的 Armadillo Android 演示包（原版仅 armeabi-v7a、targetSdk 21）
重建为 **arm64-v8a、targetSdk 35** 的版本，并修复了在现代 Android 上的兼容性问题和多处性能问题。

| | 原版 | 本版 |
|---|---|---|
| ABI | armeabi-v7a | arm64-v8a |
| minSdk / targetSdk | 16 / 21 | 23 / 35 |
| APK 大小 | 11.7 MB（32 位） | 7.6 MB |
| `lib/` | `libflutter.so` | `libflutter.so`（AOT 快照已链接在内） |
| 签名 | 原始签名 | v1 + v2 + v3，自签名演示密钥 |
| 16 KB 页设备 | — | 支持（ELF 段 16 KB 对齐） |

已在 OnePlus（Android 16，Snapdragon，120 Hz）上验证：功能完整，滚动、长按、拖拽叠放流畅。

---

## 目录结构

```
apk/armadillo-arm64.apk        最终 APK
patches/
  flutter-engine.patch          Flutter engine 3a12bc09 的修改
  dart-sdk.patch                Dart SDK（engine DEPS 钉住的版本）的修改
  buildroot.patch               buildroot 的修改（arm64 改用 lld）
  armadillo-app.patch           Armadillo Dart 源码的修改（相对 topaz 原始源码）
  diagnostics/                  可选诊断补丁（不用于正式构建）
    flutter-framework-frame-profiler.patch   每帧分阶段耗时 + 重建/布局/重绘统计
    dart-vm-gc-log.patch                     GC 停顿日志（需先打 dart-sdk.patch）
app/                            已打好补丁的完整 Dart 源码
  shell/{armadillo,keyboard,widgets}  armadillo 本体
  lib_widgets/                  lib.widgets 包
  widgets_meta/                 widgets_meta 占位实现（原仓库已下线）
  pub-versions.json             pub 依赖的版本（按 2017-07-24 解析）
tools/
  fetch_deps.py                 精简版 gclient：按 DEPS 浅克隆依赖（只解析，不执行 DEPS）
  fetch_pub.py                  按指定日期解析并下载 pub 包
  axml.py                       Android 二进制 XML 编解码
  make_manifest.py              由原版 manifest 生成最终 manifest
  slim_flx.py                   精简 app.flx（图片压缩、删除无用资源）
  pack2.py                      重新打包 APK
  build_apk.sh                  一键：生成快照 → 链接进引擎 → 打包 → 对齐 → 签名
build-inputs/
  AndroidManifest.xml           实际使用的二进制 manifest
  packages.template             Dart .packages 模板
  dart_vm_entry_points.txt      AOT 入口清单（来自 engine 3a12bc09 的 android-arm-release 产物）
  dart_io_entries.txt
  icu-remove.txt                从 icudtl.dat 删除的条目（495 项）
  signing/demo.jks              演示签名密钥（alias demo，密码 android）
```

> `demo.jks` 是专门为这个演示生成的一次性自签名密钥，保留它只是为了让后续构建能覆盖安装。
> 不要用于任何其他用途。

---

## 来源与版本

| 组件 | 版本 | 说明 |
|---|---|---|
| Armadillo 源码 | topaz `b0329ce2`（2017-07-25） | `ae8b9d588`「Remove non-fuchsia specific files」的父提交，最后一个仍含 Android 入口的版本 |
| lib.widgets | topaz `38d060a6`（2017-07-25） | 位于 `public/dart/widgets`（topaz 导入历史后的路径） |
| Flutter 框架 | `9f510ebd`（2017-07-25） | 对比 engine `3a12bc09` 覆盖的几个提交，编出的 arm32 快照与原版差异最小（isolate 指令段只差 112 字节） |
| Flutter engine | `3a12bc09` | 原版 `libflutter.so` 与该版本官方 android-arm-release 产物逐字节一致 |
| buildroot | `b0b836db` | engine DEPS 钉住 |
| Dart SDK（源码） | `a83a69ff` | engine DEPS 钉住；快照版本 hash `e456eb7aae1154776e136fdcb1a4d9ea` |
| Skia | `89d9d955` | engine DEPS 钉住 |
| pub 依赖 | 见 `app/pub-versions.json` | 取 2017-07-24 前最后发布的版本 |

### 已下线依赖的替代来源

| 原依赖 | 替代 |
|---|---|
| fuchsia `ftl` | garnet `7babf671`（`public/lib/ftl`，2017-07-18，engine 钉住日期前的最后一次修改） |
| fuchsia `zip` | garnet `125d1175`（`public/lib/zip`） |
| skia `libjpeg-turbo` 镜像 | chromium `deps/libjpeg_turbo`（2017-07 的提交） |
| fuchsia `third_party/gtest` | googletest `release-1.8.0` + 手写 `BUILD.gn`（只有测试用到） |
| `widgets_meta` | `app/widgets_meta` 占位实现，只含 `ExampleSize`/`ExampleValue` 两个注解类 |

### 构建工具链

| 工具 | 版本 | 原因 |
|---|---|---|
| gn | Chromium r486916（`chromium-gn` bucket，2017-07） | Fuchsia 的 buildtools bucket 已不可访问 |
| clang | LLVM 5.0.1（releases.llvm.org） | 原版用 Fuchsia clang 5.0；需要 `libtinfo5` |
| NDK | r12b | 提供 sysroot、libgcc、binutils，与原版一致 |
| 链接器（arm64） | lld 18.1.3（Ubuntu 官方源） | 支持 `--pack-dyn-relocs=android` |
| Python | 2.7.18（源码编译） | 2017 年构建脚本依赖 |
| Dart SDK（主机） | 1.24.2 | 构建期工具 |
| Android build-tools | 36（zipalign、apksigner、aapt2） | |

---

## 构建步骤

以下命令中，`$W` 为工作目录，`$PKG` 为本包解压后的目录，主机为 x86_64 Linux。

### 1. 引擎源码

```bash
# engine 本体
mkdir -p $W/engine/src/flutter && cd $W/engine/src/flutter
git init -q && git remote add origin https://github.com/flutter/engine
git fetch --depth 1 origin 3a12bc092d58528dce40e7378b29d0a14c952ec0 && git checkout FETCH_HEAD

# 按 DEPS 拉取依赖（不执行 DEPS，只做语法解析）
cd $W/engine && git -C src/flutter show HEAD:DEPS > DEPS.engine
python3 -I $PKG/tools/fetch_deps.py $W/engine $W/engine/DEPS.engine
```

`ftl`、`zip`、`libjpeg-turbo`、`gtest` 会拉取失败，按上面「替代来源」放入
`src/lib/ftl`、`src/lib/zip`、`src/third_party/libjpeg-turbo`、`src/third_party/gtest`。

### 2. 工具链

- `src/buildtools/linux64/gn`：放入 r486916 的 gn；`ninja` 用系统自带的即可
- `src/buildtools/toolchain/clang+llvm-x86_64-linux`：LLVM 5.0.1
- `src/third_party/android_tools/ndk`：NDK r12b
- `src/dart/tools/sdks/linux/dart-sdk`：Dart SDK 1.24.2
- `/usr/lib/llvm-18/bin/ld.lld`：`apt install lld-18`
- `python` 指向 Python 2.7

### 3. 打补丁、编译引擎

```bash
cd $W/engine/src
git apply $PKG/patches/buildroot.patch
git -C flutter apply $PKG/patches/flutter-engine.patch
git -C dart apply $PKG/patches/dart-sdk.patch

python flutter/tools/gn --android --android-cpu arm64 --runtime-mode release
ninja -C out/android_release_arm64 clang_x64/gen_snapshot \
      flutter/sky/packages/sky_engine:sky_engine
```

`libflutter.so` 依赖 AOT 快照汇编，由第 5 步的 `build_apk.sh` 生成后再链接，不用单独编译。

### 4. Dart 依赖与资源

```bash
# Flutter 框架
git clone https://github.com/flutter/flutter $W/flutter
git -C $W/flutter checkout 9f510ebdc991ef96525c5e268a94805c1370e8b2

# armadillo 源码：直接用本包的 app/（已打补丁）
cp -r $PKG/app $W/app

# pub 包（按 2017-07-24 解析）
python3 -I $PKG/tools/fetch_pub.py 2017-07-24 $W/app/pub collection http intl meta typed_data vector_math

# .packages：替换模板中的 ${APP} ${FLUTTER} ${ENGINE_OUT}
sed -e "s|\${APP}|$W/app|; s|\${FLUTTER}|$W/flutter|; s|\${ENGINE_OUT}|$W/engine/src/out/android_release_arm64|" \
    $PKG/build-inputs/packages.template > $W/app/.packages

# 资源：从原版 APK 解出 app.flx / icudtl.dat 并精简
unzip -p armadillo-20170726.apk assets/app.flx > app.flx.orig
python3 -I $PKG/tools/slim_flx.py app.flx.orig $W/slim/app.flx
unzip -p armadillo-20170726.apk assets/icudtl.dat > icudt54l.dat
mkdir min && icupkg -r $PKG/build-inputs/icu-remove.txt icudt54l.dat min/icudt54l.dat
cp min/icudt54l.dat $W/slim/icudtl.dat
```

`icupkg` 来自 `apt install icu-devtools`，它按文件名判断包名前缀，所以文件必须叫 `icudt54l.dat`。

### 5. 生成 APK

```bash
ENGINE_SRC=$W/engine/src APP=$W/app BUILD_TOOLS=$ANDROID_HOME/build-tools/36.0.0 \
ORIG_APK=armadillo-20170726.apk FLX=$W/slim/app.flx ICU=$W/slim/icudtl.dat \
  $PKG/tools/build_apk.sh armadillo-arm64.apk
```

脚本依次完成：`gen_snapshot` 输出汇编 → 截掉 DWARF → 链接进 `libflutter.so` → 打包
→ `zipalign -P 16` → `apksigner`（v1/v2/v3）。改了 Dart 代码以后只要重新跑这一步，
引擎只需重新链接，大约 20 秒。

> `gen_snapshot` 的输出本身不是确定性的：同一输入连续两次生成，VM 指令段相同，
> 其余三段内容不同，但大小完全一致。所以每次构建出的 `libflutter.so` 不会逐字节相同，属正常现象。

---

## 修改清单

### 引擎（`flutter-engine.patch`）

| 文件 | 修改 | 原因 |
|---|---|---|
| `shell/common/engine.cc` | Android 上直接引用链接进来的 `_kDart*Snapshot*` 符号，删除 mmap 文件的加载代码 | 快照随引擎一起作为代码段加载，和 iOS 的做法相同；`lib/` 只剩一个库，也不再需要从数据目录映射可执行代码（targetSdk ≥ 29 禁止） |
| `shell/platform/android/BUILD.gn` | 加入 `app_snapshot/snapshot.S`；`max-page-size=16384`、`--icf=safe`、`--pack-dyn-relocs=android` | 链接快照；支持 16 KB 页；合并相同函数；重定位表从 729 KB 压到 76 KB |
| `shell/common/perf_hint.{h,cc}`（新增） | ADPF 性能提示：UI、GPU 线程各开一个会话，每帧上报耗时，目标时长取实测 vsync 间隔 | 让调度器在 120 Hz 下给这两个线程分配足够的 CPU 资源。运行时通过 `dlsym` 解析，API 33 以下自动不生效 |
| `shell/common/animator.cc` | 上报 UI 帧耗时；帧结束 100 ms 内没有新帧时调用 `Engine::NotifyIdle()` | ADPF；以及在界面静止时提前做 GC |
| `shell/gpu/gpu_rasterizer.cc` | 上报光栅化耗时 | ADPF |
| `shell/platform/android/vsync_waiter_android.cc` | 记录 vsync 间隔 | 作为 ADPF 的目标帧时长 |
| `shell/common/engine.{h,cc}`、`runtime/runtime_controller.{h,cc}` | `NotifyIdle()` 传递链，进入 isolate 后调用 `Dart_NotifyIdle()` | 空闲 GC |

### Dart SDK（`dart-sdk.patch`）

| 文件 | 修改 | 原因 |
|---|---|---|
| `runtime/vm/heap.{h,cc}`、`pages.{h,cc}` | `Heap::NotifyIdle()`：老年代已用掉下次 GC 前一半以上的增长空间时，提前做完整回收；新生代超过一半时先做一次 Scavenge | 2017 年的 VM 只在分配内存时被动触发全停顿的标记清除（约 13 ms），常常打断动画中的帧 |
| `runtime/include/dart_api.h` | 声明 `Dart_NotifyIdle()` | 同上（2018 年以后的官方 Dart 也有同名接口） |
| `runtime/vm/heap.cc` | `Dart_NotifyIdle()` 的实现放在这里，而不是 `dart_api_impl.cc` | 快照版本 hash 由包括 `dart_api_impl.cc` 在内的一组源文件计算，放在那里会改变 hash，导致快照被拒绝加载 |
| `runtime/bin/BUILD.gn` | Android 上开启 `DART_IO_SECURE_SOCKET_DISABLED`，不再链接 BoringSSL | armadillo 不联网；去掉约 0.4 MB。`SecureSocket` 如果被调用，会抛出"不支持"异常 |

### buildroot（`buildroot.patch`）

arm64 改用 `/usr/lib/llvm-18/bin/ld.lld`，其他架构仍用 gold。

### Armadillo（`armadillo-app.patch`）

| 文件 | 修改 | 原因 |
|---|---|---|
| `story_panels.dart` | `_getElevation` 中 `null + null` 改为按 0 处理 | 布局走到某条分支时，相关模拟器尚未挂载，每帧抛异常，故事区整块空白 |
| `story_panels.dart` | 只有被拖动的卡片监听拖动进度；占位卡片复用已缓存的故事 widget | 其他卡片拿到拖动进度也不使用，每帧白白重建 |
| `story_list.dart` | 故事卡片 widget 移出每帧运行的 builder，只在 `StoryModel` 变化时构建 | 原来滚动、拖动、遮罩动画的每一帧都会重建所有卡片 |
| `render_story_list_body.dart`、`story_list_body_parent_data.dart` | 长按时的缩放从"每帧改布局尺寸"改为"布局尺寸固定、绘制时矩阵缩放"；命中测试和 `applyPaintTransform` 同步处理。布局尺寸用不含缩放系数的独立公式计算 | 原来每帧所有卡片都要重新布局。如果用"先乘后除"还原尺寸，浮点误差会让约束每帧变化，同样触发全量重新布局 |
| `story_cluster_widget.dart` | 卡片标题的淡出加上 `RepaintBoundary` 隔离 | 标题透明度变化会把重绘传到整张卡片，每帧重新录制所有卡片 |
| `now.dart`、`quick_settings.dart`、`simulated_transform.dart` | 动画中的 `Opacity` 或变换内部加 `RepaintBoundary` | 同上：Now 栏淡出、快捷设置淡入、拖动时浮起的卡片 |

改动只涉及性能和兼容性，视觉和交互逻辑保持不变。唯一可见的差异是：长按时卡片下方的标题会跟卡片一起缩到 0.9 倍（原来标题高度不缩放）。

### Manifest（`tools/make_manifest.py`）

- `minSdkVersion` 16 → 23：压缩重定位格式需要 API 23
- `targetSdkVersion` 21 → 35
- `<activity android:exported="true">`：targetSdk ≥ 31 必须声明
- `<application android:allowNativeHeapPointerTagging="false">`：见下文"指针标记"

### 资源（`tools/slim_flx.py`、`build-inputs/icu-remove.txt`）

- `User.png`：实际是 1365² 的 JPEG（1.2 MB），而头像最大只显示约 200 px，缩为 384² JPEG（30 KB）
- `Background.jpg`：分辨率不变，改为质量 90 的渐进式 JPEG（923 KB → 117 KB）
- 删除 `Armadillo.png`：只列在资源清单里，代码和数据都没有引用
- `icudtl.dat`：删除排序规则（`coll/`）和地区显示数据（`zone/curr/unit/lang/region`），6.3 MB → 3.2 MB。引擎从不创建 `Collator`，也不调用 ICU 的日期、数字格式化接口

---

## 问题排查记录

按出现顺序：

1. **原版只有 32 位，且没有官方 arm64 产物**：engine `3a12bc09` 的 arm64 产物在 2018 年以后才开始发布，所以只能从源码编译引擎，并用原始 Dart 源码重新生成 arm64 快照。
2. **2017 年的引擎把快照放在 `assets/`**：32 位和 64 位只能共用一份。最初改为放进 `lib/arm64-v8a/lib*.so`，最终改成直接链接进 `libflutter.so`。
3. **`FlutterMain.initAot()` 要求 4 个快照资源存在**：删掉 assets 里的快照后，Java 端不再传快照路径，引擎启动检查失败。一开始用空文件占位；快照链接进引擎、删除那个检查后，占位文件也去掉了。
4. **targetSdk ≥ 29 的 W^X 限制**：不允许从数据目录映射可执行代码，原版 32 位的加载方式会失效。
5. **`_getElevation` 空值异常**：targetSdk 35 强制全屏显示后窗口尺寸变化，布局走到原本走不到的分支。
6. **堆指针标记（targetSdk ≥ 30）**：64 位应用的 malloc 指针最高字节带标签，2017 年的引擎和 Dart VM 不识别。表现为资源全部加载不出来，而且没有任何报错。用 targetSdk 29/30 对比确认后，通过 manifest 开关关闭。
7. **120 Hz 卡顿**：依次修了列表每帧重建、长按缩放每帧重新布局、标题淡出导致整卡重绘、浮点误差造成的约束抖动（最后这个是用帧剖析补丁定位到的）。
8. **老年代 GC**：用 GC 日志补丁确认，剩下唯一明显的卡顿来自 `reason=full` 的标记清除（约 13 ms），于是加了空闲 GC。
9. **体积**：快照链接进引擎；去掉 BoringSSL；压缩重定位；ICF；资源精简。

### 诊断补丁的用法

```bash
# 帧剖析：打在 Flutter 框架上，然后用这份框架重新生成快照
patch -p1 -d $W/flutter < $PKG/patches/diagnostics/flutter-framework-frame-profiler.patch
# GC 日志：在 dart-sdk.patch 之后打
git -C $W/engine/src/dart apply $PKG/patches/diagnostics/dart-vm-gc-log.patch

adb logcat -v time -s flutter DartVM | grep -E "PROF|GCPROF"
```

UI 线程超过 6 ms 的帧会打印 `PROF frame`（分阶段耗时），以及这一帧重建、布局、重绘最多的类型。
超过 1 ms 的 GC 会打印 `GCPROF`，包括类型（Scavenge / Mark-Sweep）、耗时和触发原因。

---

## 已知限制

- 仅 arm64，需要 Android 6.0 及以上
- 去掉了 `.eh_frame` 以外所有可安全移除的部分；`.eh_frame`（约 0.7 MB）保留，用于崩溃时的 native 调用栈
- `dart:io` 不支持 TLS（armadillo 不联网）
- targetSdk 35 强制全屏显示：界面会延伸到状态栏和导航栏下面。armadillo 本身不读取系统栏边距，实测显示正常
- 安装时，系统会把 18 MB 的 `libflutter.so` 解压到磁盘。如果改用 `extractNativeLibs=false`、在 APK 内不压缩存放，可以省掉这部分安装占用，代价是 APK 变成约 20 MB
