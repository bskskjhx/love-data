#!/bin/bash
# Build the armadillo arm64 APK:
#   1. gen_snapshot -> AOT snapshot as assembly
#   2. link it into libflutter.so (engine source tree + ninja)
#   3. pack: original APK minus old snapshots/libs/signature + new manifest,
#      engine, slimmed assets -> zipalign -> apksigner
#
# Usage: build_apk.sh <output.apk>
# Environment (defaults match the original build machine):
#   ENGINE_SRC   engine checkout root (contains flutter/, dart/, out/)
#   APP          armadillo app tree (shell/, lib_widgets/, widgets_meta/, pub/)
#   PACKAGES     .packages file for the app (see build-inputs/packages.template)
#   ENTRY_POINTS dir with dart_vm_entry_points.txt and dart_io_entries.txt
#   BUILD_TOOLS  Android build-tools dir (zipalign, apksigner)
#   ORIG_APK     the original armadillo-20170726.apk
#   MANIFEST     binary AndroidManifest.xml to ship (tools/make_manifest.py)
#   FLX, ICU     slimmed assets/app.flx and assets/icudtl.dat
#   KEYSTORE     signing keystore (alias "demo", password "android")
set -euo pipefail
OUT=$1
HERE=$(cd "$(dirname "$0")" && pwd)
ENGINE_SRC=${ENGINE_SRC:-/home/claude/engine/src}
APP=${APP:-/home/claude/app}
PACKAGES=${PACKAGES:-$APP/.packages}
ENTRY_POINTS=${ENTRY_POINTS:-$HERE/../build-inputs}
BUILD_TOOLS=${BUILD_TOOLS:-/home/claude/sdk/android-16}
ORIG_APK=${ORIG_APK:-/home/claude/apk/in.apk}
MANIFEST=${MANIFEST:-$HERE/../build-inputs/AndroidManifest.xml}
FLX=${FLX:-/home/claude/slim/app.flx}
ICU=${ICU:-/home/claude/slim/icudtl.dat}
KEYSTORE=${KEYSTORE:-$HERE/../build-inputs/signing/demo.jks}

O=$ENGINE_SRC/out/android_release_arm64
SKY=$O/gen/dart-pkg/sky_engine
SNAP_S=$ENGINE_SRC/flutter/shell/platform/android/app_snapshot/snapshot.S
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

# 1. AOT snapshot as assembly.
( cd "$WORK" && "$O/clang_x64/gen_snapshot" --assert_initializer --await_is_keyword \
  --snapshot_kind=app-aot-assembly --assembly=snapshot.S \
  --packages="$PACKAGES" \
  --url_mapping=dart:ui,$SKY/lib/ui/ui.dart \
  --url_mapping=dart:vmservice_sky,$SKY/sdk_ext/vmservice_io.dart \
  --embedder_entry_points_manifest="$ENTRY_POINTS/dart_vm_entry_points.txt" \
  --embedder_entry_points_manifest="$ENTRY_POINTS/dart_io_entries.txt" \
  "$APP/shell/armadillo/lib/main.dart" )

# 2. Drop DWARF (never loaded, stripped anyway) and link into libflutter.so.
mkdir -p "$(dirname "$SNAP_S")"
n=$(grep -n '^\.section \.debug_abbrev' "$WORK/snapshot.S" | head -1 | cut -d: -f1)
head -n $((n - 1)) "$WORK/snapshot.S" > "$SNAP_S"
( cd "$O" && ninja -j"$(nproc)" lib.stripped/libflutter.so | tail -1 )

# 3. Pack, align, sign.
python3 -I "$HERE/pack2.py" "$ORIG_APK" "$WORK/u.apk" "$MANIFEST" \
  arm64-v8a="$O/lib.stripped/libflutter.so" \
  asset:app.flx="$FLX" asset:icudtl.dat="$ICU"
"$BUILD_TOOLS/zipalign" -P 16 -f 4 "$WORK/u.apk" "$WORK/a.apk"
"$BUILD_TOOLS/apksigner" sign --ks "$KEYSTORE" --ks-pass pass:android \
  --ks-key-alias demo --v4-signing-enabled false --out "$OUT" "$WORK/a.apk"
"$BUILD_TOOLS/apksigner" verify "$OUT"
echo "built $OUT"
