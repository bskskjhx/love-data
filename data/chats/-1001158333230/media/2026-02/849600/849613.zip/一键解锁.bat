@echo off
chcp 65001 >nul
title 小米17系列BL一键解锁工具
mode con cols=85 lines=35

:: ===================== 前置校验与免责确认 =====================
echo.
echo =================================================================================
echo                         小米17系列BL一键解锁工具
echo                              基于泛滥代码漏洞优化
echo                              工具制作1689515637
echo =================================================================================
echo.
echo 【最高风险提醒】
echo 1. 本工具仅可用于本人合法拥有的设备，未经授权使用需承担法律责任
echo 2. 操作存在极高变砖风险，已自动配置原机分区备份，请勿跳过备份步骤
echo 3. 继续使用即视为您已完全同意免责声明的全部条款
echo.
set /p confirm=是否确认继续操作？(输入Y确认，其他任意键退出)：
if /i not "%confirm%"=="Y" exit

:: 管理员权限校验
fltmc >nul 2>&1 || (
    echo 【错误】请右键点击脚本，选择「以管理员身份运行」！
    pause
    exit
)

:: 文件完整性校验
if not exist "配置文件.ini" (
    echo 【错误】配置文件.ini 缺失，请检查工具包完整性
    pause
    exit
)
if not exist "bin\" (
    echo 【错误】bin依赖目录缺失，请检查工具包完整性
    pause
    exit
)
if not exist "firmware\" (
    echo 【错误】firmware固件目录缺失，请检查工具包完整性
    pause
    exit
)
if not exist "scripts\" (
    echo 【错误】scripts脚本目录缺失，请检查工具包完整性
    pause
    exit
)

:: 加载用户配置
for /f "tokens=2 delims==" %%a in ('findstr "firehose_file" 配置文件.ini') do set firehose_file=%%a
for /f "tokens=2 delims==" %%a in ('findstr "device_lock_addr" 配置文件.ini') do set device_lock_addr=%%a
for /f "tokens=2 delims==" %%a in ('findstr "unlock_value" 配置文件.ini') do set unlock_value=%%a
for /f "tokens=2 delims==" %%a in ('findstr "spray_count" 配置文件.ini') do set spray_count=%%a
for /f "tokens=2 delims==" %%a in ('findstr "hole_interval" 配置文件.ini') do set hole_interval=%%a
for /f "tokens=2 delims==" %%a in ('findstr "exploit_wait_time" 配置文件.ini') do set exploit_wait_time=%%a

:: 漏洞固件校验
if not exist "firmware\xbl_3.0.17.img" (
    echo 【错误】firmware目录下缺失 xbl_3.0.17.img 漏洞固件
    pause
    exit
)
if not exist "firmware\abl_3.0.17.img" (
    echo 【错误】firmware目录下缺失 abl_3.0.17.img 漏洞固件
    pause
    exit
)
if not exist "bin\Firehose\%firehose_file%" (
    echo 【错误】Firehose文件缺失，请检查配置文件与bin\Firehose目录
    pause
    exit
)

:: ===================== 环境自动配置 =====================
echo.
echo [1/6] 正在自动安装USB驱动与运行环境...
:: 安装高通9008驱动
cd bin\driver
devcon install qcser.inf "USB\VID_05C6&PID_9008" >nul 2>&1
:: 安装libusb驱动
infinstaller.exe /install /silent "libusb0.inf" >nul 2>&1
cd ..\..
:: 安装Python依赖
python -m pip install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple >nul 2>&1
python -m pip install pyserial libusb pyusb configparser facedancer -i https://pypi.tuna.tsinghua.edu.cn/simple >nul 2>&1
echo 环境配置完成，所有依赖已安装

:: ===================== 核心流程自动化执行 =====================
echo.
echo [2/6] 正在准备EDL降级操作...
echo 请将目标手机进入EDL模式（9008端口），连接电脑，完成后按任意键继续...
pause >nul

:: 自动备份原机分区（防变砖）
echo.
echo [3/6] 正在自动备份原机XBL/ABL分区...
python scripts\edl_operate.py --mode backup --firehose bin\Firehose\%firehose_file% --backup_dir firmware\backup\
if %errorlevel% neq 0 (
    echo 【错误】原机分区备份失败，请检查EDL连接与驱动
    pause
    exit
)
echo 原机分区备份完成，已保存至 firmware\backup\ 目录，变砖可直接刷回恢复

:: 刷入漏洞固件
echo.
echo [4/6] 正在刷入3.0.17漏洞固件...
python scripts\edl_operate.py --mode flash --firehose bin\Firehose\%firehose_file% --xbl firmware\xbl_3.0.17.img --abl firmware\abl_3.0.17.img
if %errorlevel% neq 0 (
    echo 【错误】漏洞固件刷入失败，请检查EDL连接与固件文件
    pause
    exit
)
echo 漏洞固件刷入完成，设备已成功降级到3.0.17可利用版本

:: 漏洞触发
echo.
echo [5/6] 正在准备漏洞触发...
echo 请将Facedancer硬件连接电脑，目标手机保持关机状态，完成后按任意键开始...
pause >nul
echo 漏洞触发脚本已启动，请给目标手机开机，等待UEFI枚举...
python scripts\facedancer_exploit.py --lock_addr %device_lock_addr% --unlock_val %unlock_value% --spray %spray_count% --interval %hole_interval% --wait %exploit_wait_time%
if %errorlevel% neq 0 (
    echo 【错误】漏洞触发失败，请检查固件版本、Facedancer连接与设备锁地址
    pause
    exit
)
echo 漏洞触发成功！设备锁状态已覆盖为解锁状态

:: Fastboot解锁
echo.
echo [6/6] 正在执行Fastboot最终解锁...
echo 请将目标手机进入Fastboot模式，连接电脑，完成后按任意键继续...
pause >nul
bin\fastboot.exe devices
echo 正在执行解锁命令，请在手机上按音量键确认解锁...
bin\fastboot.exe flashing unlock
if %errorlevel% neq 0 (
    echo 【警告】解锁命令执行失败，请重试漏洞触发步骤，确认状态覆盖生效
    pause
    exit
)
bin\fastboot.exe reboot

:: 完成提示
echo.
echo =================================================================================
echo                              恭喜！BL锁解锁成功！
echo =================================================================================
echo 设备已重启，您可通过 fastboot getvar unlocked 命令验证解锁状态
echo 如需恢复官方固件，可使用 firmware\backup\ 目录下的备份文件刷回
echo.
pause
exit
