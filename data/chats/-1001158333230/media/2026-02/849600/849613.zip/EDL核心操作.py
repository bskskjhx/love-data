import argparse
import os
import sys
from edl import EDL

def main():
    parser = argparse.ArgumentParser(description="小米17系列EDL分区操作工具")
    parser.add_argument("--mode", required=True, choices=["backup", "flash"], help="操作模式：backup备份原分区，flash刷入漏洞固件")
    parser.add_argument("--firehose", required=True, help="Firehose刷机文件路径")
    parser.add_argument("--backup_dir", help="备份目录，backup模式必填")
    parser.add_argument("--xbl", help="XBL漏洞固件路径，flash模式必填")
    parser.add_argument("--abl", help="ABL漏洞固件路径，flash模式必填")
    args = parser.parse_args()

    # 初始化EDL连接
    try:
        edl = EDL(firehose=args.firehose, skip_reset=False)
        edl.connect()
        print("✅ EDL设备连接成功，已识别9008端口")
    except Exception as e:
        print(f"❌ EDL连接失败：{str(e)}")
        sys.exit(1)

    # 备份模式：备份AB分区，防止变砖
    if args.mode == "backup":
        if not args.backup_dir:
            print("❌ 备份模式必须指定--backup_dir参数")
            sys.exit(1)
        os.makedirs(args.backup_dir, exist_ok=True)
        
        try:
            print("正在备份XBL主分区...")
            edl.dump_partition("xbl", os.path.join(args.backup_dir, "xbl_backup.img"))
            print("正在备份XBL_B备份分区...")
            edl.dump_partition("xblbak", os.path.join(args.backup_dir, "xblbak_backup.img"))
            print("正在备份ABL主分区...")
            edl.dump_partition("abl", os.path.join(args.backup_dir, "abl_backup.img"))
            print("正在备份ABL_B备份分区...")
            edl.dump_partition("ablbak", os.path.join(args.backup_dir, "ablbak_backup.img"))
            edl.disconnect()
            print("✅ 所有分区备份完成")
            sys.exit(0)
        except Exception as e:
            print(f"❌ 分区备份失败：{str(e)}")
            edl.disconnect()
            sys.exit(1)

    # 刷入模式：双分区刷入，确保AB槽都为漏洞固件
    if args.mode == "flash":
        if not args.xbl or not args.abl:
            print("❌ 刷入模式必须指定--xbl和--abl参数")
            sys.exit(1)
        if not os.path.exists(args.xbl) or not os.path.exists(args.abl):
            print("❌ XBL或ABL固件文件不存在")
            sys.exit(1)
        
        try:
            print("正在刷入XBL主分区...")
            edl.flash_partition("xbl", args.xbl)
            print("正在刷入XBL_B备份分区...")
            edl.flash_partition("xblbak", args.xbl)
            print("正在刷入ABL主分区...")
            edl.flash_partition("abl", args.abl)
            print("正在刷入ABL_B备份分区...")
            edl.flash_partition("ablbak", args.abl)
            edl.reset()
            edl.disconnect()
            print("✅ 漏洞固件刷入完成，设备已重启")
            sys.exit(0)
        except Exception as e:
            print(f"❌ 固件刷入失败：{str(e)}")
            edl.disconnect()
            sys.exit(1)

if __name__ == "__main__":
    main()
